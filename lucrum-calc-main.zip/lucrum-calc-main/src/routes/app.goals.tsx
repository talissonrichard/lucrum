import { createFileRoute } from "@tanstack/react-router";
import { GoalsPage } from "@/features/goals/GoalsPage";
export const Route = createFileRoute("/app/goals")({
  head: () => ({ meta: [{ title: "Metas — Lucrum" }] }),
  component: GoalsPage,
});
