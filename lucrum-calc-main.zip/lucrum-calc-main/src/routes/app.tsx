import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/features/shared/AppShell";

export const Route = createFileRoute("/app")({
  component: AppShell,
});
