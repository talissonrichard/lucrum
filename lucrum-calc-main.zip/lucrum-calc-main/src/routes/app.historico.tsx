import { createFileRoute } from "@tanstack/react-router";
import { SimulationLogsPage } from "@/features/simulations/SimulationLogsPage";

export const Route = createFileRoute("/app/historico")({
  head: () => ({ meta: [{ title: "Histórico — Lucrum" }] }),
  component: SimulationLogsPage,
});
