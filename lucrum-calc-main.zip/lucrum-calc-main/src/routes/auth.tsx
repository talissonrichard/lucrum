import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useAuth } from "@/features/auth/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import authHero from "@/assets/auth-hero.jpg";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "Entrar — Lucrum" }] }),
  component: AuthPage,
});

function AuthPage() {
  const { user, signIn, signUp, loading } = useAuth();
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [nome, setNome] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (!loading && user) nav({ to: "/app" }); }, [user, loading, nav]);

  const submit = async (mode: "in" | "up") => {
    setBusy(true);
    const r = mode === "in" ? await signIn(email, password) : await signUp(email, password, nome);
    setBusy(false);
    if (r.error) toast.error(r.error);
    else if (mode === "up") toast.success("Conta criada. Verifique seu e-mail se a confirmação estiver ativa.");
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-background">
      <div className="hidden lg:flex relative flex-col justify-between p-12 text-sidebar-foreground overflow-hidden" style={{ background: "var(--gradient-primary)" }}>
        <img
          src={authHero}
          alt="Gráfico de crescimento de margem com moedas e etiquetas de preço"
          className="absolute inset-0 w-full h-full object-cover opacity-40 mix-blend-luminosity"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, oklch(0.40 0.13 165 / 0.85), oklch(0.55 0.14 150 / 0.55))" }} />
        <div className="relative flex items-center gap-2">
          <div className="h-9 w-9 rounded-lg bg-white/15 backdrop-blur grid place-items-center font-bold">L</div>
          <span className="font-semibold tracking-tight text-lg">Lucrum</span>
        </div>
        <div className="relative max-w-md">
          <h1 className="text-4xl font-semibold leading-tight tracking-tight drop-shadow-md">Decida com margem real, não com achismo.</h1>
          <p className="mt-4 text-white/90">Simule preço, comissão, imposto e custos por canal antes de aceitar uma campanha. Em segundos.</p>
        </div>
        <div className="relative text-xs text-white/70">© Lucrum</div>
      </div>

      <div className="flex items-center justify-center p-6">
        <Card className="w-full max-w-md shadow-[var(--shadow-elevated)]">
          <CardHeader>
            <CardTitle>Acessar Lucrum</CardTitle>
            <CardDescription>Entre com sua conta para simular margens.</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="in">
              <TabsList className="grid grid-cols-2 w-full">
                <TabsTrigger value="in">Entrar</TabsTrigger>
                <TabsTrigger value="up">Criar conta</TabsTrigger>
              </TabsList>

              <TabsContent value="in" className="space-y-3 mt-4">
                <div><Label>E-mail</Label><Input type="email" value={email} onChange={e => setEmail(e.target.value)} /></div>
                <div><Label>Senha</Label><Input type="password" value={password} onChange={e => setPassword(e.target.value)} /></div>
                <Button className="w-full" disabled={busy} onClick={() => submit("in")}>Entrar</Button>
              </TabsContent>

              <TabsContent value="up" className="space-y-3 mt-4">
                <div><Label>Nome</Label><Input value={nome} onChange={e => setNome(e.target.value)} /></div>
                <div><Label>E-mail</Label><Input type="email" value={email} onChange={e => setEmail(e.target.value)} /></div>
                <div><Label>Senha</Label><Input type="password" value={password} onChange={e => setPassword(e.target.value)} /></div>
                <Button className="w-full" disabled={busy} onClick={() => submit("up")}>Criar conta</Button>
                <p className="text-xs text-muted-foreground">Após criar, peça ao admin para vincular sua conta a uma empresa.</p>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
