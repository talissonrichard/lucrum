import { createFileRoute } from "@tanstack/react-router";
import { DashboardPage } from "@/features/dashboard/DashboardPage";

export const Route = createFileRoute("/app/")({
  head: () => ({ meta: [{ title: "Dashboard — Lucrum" }] }),
  component: DashboardPage,
});
