import { createFileRoute } from "@tanstack/react-router";
import { Simulator } from "@/features/simulations/Simulator";

export const Route = createFileRoute("/app/simulator")({
  head: () => ({ meta: [{ title: "Simulador — Lucrum" }] }),
  validateSearch: (s: Record<string, unknown>) => ({ produto: s.produto ? Number(s.produto) : undefined }),
  component: Simulator,
});
