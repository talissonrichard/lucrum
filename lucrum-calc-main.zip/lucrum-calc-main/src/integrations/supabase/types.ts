export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      bi_agenda_obrigacoes: {
        Row: {
          data_chegada: string | null
          data_finalizacao: string | null
          data_hora_liberacao: string | null
          data_hora_revisao: string | null
          data_inicio: string | null
          data_recebimento: string | null
          data_vencto_obrigacao: string | null
          dthr_atualizacao: string | null
          dthr_cadastro: string | null
          duracao: string | null
          etl_last_update: string | null
          hora_fim_ligacao: string | null
          hora_final: string | null
          hora_inicio: string | null
          hora_inicio_ligacao: string | null
          id_agenda_campanha: number | null
          id_andamento_atual: number | null
          id_cliente: number | null
          id_cliente_obrigacoes: number | null
          id_empresa: number | null
          id_funcionario: number | null
          id_funcionario_entrega: number | null
          id_funcionario_responsavel: number | null
          id_motivo_finalizacao: number | null
          id_nota_saida: number | null
          id_obrigacoes: number
          id_produto: number | null
          id_sequencia: number | null
          id_servico: number | null
          mensagem: string | null
          observacao: string | null
          prioridade: string | null
          produtos: string | null
          status: string | null
          status_obrigacao: string | null
          tipo: string | null
          tipo_lancto: string | null
          usuario: string | null
          usuario_liberacao: string | null
          usuario_revisao: string | null
        }
        Insert: {
          data_chegada?: string | null
          data_finalizacao?: string | null
          data_hora_liberacao?: string | null
          data_hora_revisao?: string | null
          data_inicio?: string | null
          data_recebimento?: string | null
          data_vencto_obrigacao?: string | null
          dthr_atualizacao?: string | null
          dthr_cadastro?: string | null
          duracao?: string | null
          etl_last_update?: string | null
          hora_fim_ligacao?: string | null
          hora_final?: string | null
          hora_inicio?: string | null
          hora_inicio_ligacao?: string | null
          id_agenda_campanha?: number | null
          id_andamento_atual?: number | null
          id_cliente?: number | null
          id_cliente_obrigacoes?: number | null
          id_empresa?: number | null
          id_funcionario?: number | null
          id_funcionario_entrega?: number | null
          id_funcionario_responsavel?: number | null
          id_motivo_finalizacao?: number | null
          id_nota_saida?: number | null
          id_obrigacoes: number
          id_produto?: number | null
          id_sequencia?: number | null
          id_servico?: number | null
          mensagem?: string | null
          observacao?: string | null
          prioridade?: string | null
          produtos?: string | null
          status?: string | null
          status_obrigacao?: string | null
          tipo?: string | null
          tipo_lancto?: string | null
          usuario?: string | null
          usuario_liberacao?: string | null
          usuario_revisao?: string | null
        }
        Update: {
          data_chegada?: string | null
          data_finalizacao?: string | null
          data_hora_liberacao?: string | null
          data_hora_revisao?: string | null
          data_inicio?: string | null
          data_recebimento?: string | null
          data_vencto_obrigacao?: string | null
          dthr_atualizacao?: string | null
          dthr_cadastro?: string | null
          duracao?: string | null
          etl_last_update?: string | null
          hora_fim_ligacao?: string | null
          hora_final?: string | null
          hora_inicio?: string | null
          hora_inicio_ligacao?: string | null
          id_agenda_campanha?: number | null
          id_andamento_atual?: number | null
          id_cliente?: number | null
          id_cliente_obrigacoes?: number | null
          id_empresa?: number | null
          id_funcionario?: number | null
          id_funcionario_entrega?: number | null
          id_funcionario_responsavel?: number | null
          id_motivo_finalizacao?: number | null
          id_nota_saida?: number | null
          id_obrigacoes?: number
          id_produto?: number | null
          id_sequencia?: number | null
          id_servico?: number | null
          mensagem?: string | null
          observacao?: string | null
          prioridade?: string | null
          produtos?: string | null
          status?: string | null
          status_obrigacao?: string | null
          tipo?: string | null
          tipo_lancto?: string | null
          usuario?: string | null
          usuario_liberacao?: string | null
          usuario_revisao?: string | null
        }
        Relationships: []
      }
      bi_faturas: {
        Row: {
          id_nota_saida: number
          id_nota_saida_fatura: number
          ref_numer: string | null
        }
        Insert: {
          id_nota_saida: number
          id_nota_saida_fatura: number
          ref_numer?: string | null
        }
        Update: {
          id_nota_saida?: number
          id_nota_saida_fatura?: number
          ref_numer?: string | null
        }
        Relationships: []
      }
      bi_marcas: {
        Row: {
          descricao: string | null
          etl_last_update: string | null
          id_marca: number
        }
        Insert: {
          descricao?: string | null
          etl_last_update?: string | null
          id_marca: number
        }
        Update: {
          descricao?: string | null
          etl_last_update?: string | null
          id_marca?: number
        }
        Relationships: []
      }
      bi_motivos_crm: {
        Row: {
          ativo: string | null
          descricao: string | null
          id_obrigacoes: number
        }
        Insert: {
          ativo?: string | null
          descricao?: string | null
          id_obrigacoes: number
        }
        Update: {
          ativo?: string | null
          descricao?: string | null
          id_obrigacoes?: number
        }
        Relationships: []
      }
      bi_nota_saida: {
        Row: {
          conta_frete: string | null
          data_emissao: string | null
          data_pedido: string | null
          entrega_cidade: string | null
          entrega_uf: string | null
          etl_last_update: string | null
          id_empresa: number | null
          id_nat_operacao: number | null
          id_nota_saida: number
          id_nr_nf: number | null
          id_transportadora: number | null
          parceiro: string | null
          total_nota_fiscal: number | null
        }
        Insert: {
          conta_frete?: string | null
          data_emissao?: string | null
          data_pedido?: string | null
          entrega_cidade?: string | null
          entrega_uf?: string | null
          etl_last_update?: string | null
          id_empresa?: number | null
          id_nat_operacao?: number | null
          id_nota_saida: number
          id_nr_nf?: number | null
          id_transportadora?: number | null
          parceiro?: string | null
          total_nota_fiscal?: number | null
        }
        Update: {
          conta_frete?: string | null
          data_emissao?: string | null
          data_pedido?: string | null
          entrega_cidade?: string | null
          entrega_uf?: string | null
          etl_last_update?: string | null
          id_empresa?: number | null
          id_nat_operacao?: number | null
          id_nota_saida?: number
          id_nr_nf?: number | null
          id_transportadora?: number | null
          parceiro?: string | null
          total_nota_fiscal?: number | null
        }
        Relationships: []
      }
      bi_nota_saida_itens: {
        Row: {
          custo_produto: number | null
          data_emissao: string | null
          descr_reduzida: string | null
          entrega_uf: string | null
          etl_last_update: string | null
          id_empresa: number | null
          id_nota_saida: number
          id_nr_nf: number | null
          id_produto: number
          qtde: number | null
          serie: string | null
          valor_bruto: number | null
        }
        Insert: {
          custo_produto?: number | null
          data_emissao?: string | null
          descr_reduzida?: string | null
          entrega_uf?: string | null
          etl_last_update?: string | null
          id_empresa?: number | null
          id_nota_saida: number
          id_nr_nf?: number | null
          id_produto: number
          qtde?: number | null
          serie?: string | null
          valor_bruto?: number | null
        }
        Update: {
          custo_produto?: number | null
          data_emissao?: string | null
          descr_reduzida?: string | null
          entrega_uf?: string | null
          etl_last_update?: string | null
          id_empresa?: number | null
          id_nota_saida?: number
          id_nr_nf?: number | null
          id_produto?: number
          qtde?: number | null
          serie?: string | null
          valor_bruto?: number | null
        }
        Relationships: []
      }
      bi_produtos: {
        Row: {
          descricao: string | null
          etl_last_update: string | null
          id_categoria: number | null
          id_marca: number | null
          id_produto: number
        }
        Insert: {
          descricao?: string | null
          etl_last_update?: string | null
          id_categoria?: number | null
          id_marca?: number | null
          id_produto: number
        }
        Update: {
          descricao?: string | null
          etl_last_update?: string | null
          id_categoria?: number | null
          id_marca?: number | null
          id_produto?: number
        }
        Relationships: []
      }
      bi_transporte_regras: {
        Row: {
          canal: string | null
          descricao: string | null
          id_empresa: number | null
          id_transportadora: number
          nome_site: string | null
          plataformas: string | null
        }
        Insert: {
          canal?: string | null
          descricao?: string | null
          id_empresa?: number | null
          id_transportadora: number
          nome_site?: string | null
          plataformas?: string | null
        }
        Update: {
          canal?: string | null
          descricao?: string | null
          id_empresa?: number | null
          id_transportadora?: number
          nome_site?: string | null
          plataformas?: string | null
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          created_at: string
          id: string
          message: string
          role: string
          session_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          role: string
          session_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          role?: string
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "chat_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_sessions: {
        Row: {
          created_at: string
          id: string
          titulo: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          titulo?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          titulo?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      cmv_pedidos_dia: {
        Row: {
          canal_venda: string | null
          cmv_percent: number | null
          custo_formacao_total: number | null
          data_emissao: string | null
          descr_reduzida: string | null
          faturamento: number | null
          id_nr_nf: number | null
          id_produto: number | null
          marketplace_pedido: string | null
          mb_percent: number | null
          sku: string | null
        }
        Insert: {
          canal_venda?: string | null
          cmv_percent?: number | null
          custo_formacao_total?: number | null
          data_emissao?: string | null
          descr_reduzida?: string | null
          faturamento?: number | null
          id_nr_nf?: number | null
          id_produto?: number | null
          marketplace_pedido?: string | null
          mb_percent?: number | null
          sku?: string | null
        }
        Update: {
          canal_venda?: string | null
          cmv_percent?: number | null
          custo_formacao_total?: number | null
          data_emissao?: string | null
          descr_reduzida?: string | null
          faturamento?: number | null
          id_nr_nf?: number | null
          id_produto?: number | null
          marketplace_pedido?: string | null
          mb_percent?: number | null
          sku?: string | null
        }
        Relationships: []
      }
      configuracoes: {
        Row: {
          categoria: string
          chave: string
          descricao: string | null
          id: string
          updated_at: string
          updated_by: string | null
          valor: Json
        }
        Insert: {
          categoria?: string
          chave: string
          descricao?: string | null
          id?: string
          updated_at?: string
          updated_by?: string | null
          valor?: Json
        }
        Update: {
          categoria?: string
          chave?: string
          descricao?: string | null
          id?: string
          updated_at?: string
          updated_by?: string | null
          valor?: Json
        }
        Relationships: []
      }
      controle_envios_nf_raw_bruto: {
        Row: {
          andamento: string | null
          canal: string | null
          cfop: string | null
          chavenfe: string | null
          data_emissao: string | null
          data_expedicao: string | null
          data_limite_marketplace: string | null
          dias_sem_enviar: number | null
          dthr_separacao: string | null
          id: number
          id_expedicao: number | null
          id_expedicao_previa: number | null
          id_nota_saida: number | null
          marketplace_pedido: string | null
          nf_cancelada: string | null
          numero_nota: number | null
          pedido_cancelado: string | null
          status: string | null
          status_prazo_marketplace: string | null
          status_separacao: string | null
          transportadora: string | null
          ultima_atualizacao: string | null
        }
        Insert: {
          andamento?: string | null
          canal?: string | null
          cfop?: string | null
          chavenfe?: string | null
          data_emissao?: string | null
          data_expedicao?: string | null
          data_limite_marketplace?: string | null
          dias_sem_enviar?: number | null
          dthr_separacao?: string | null
          id?: number
          id_expedicao?: number | null
          id_expedicao_previa?: number | null
          id_nota_saida?: number | null
          marketplace_pedido?: string | null
          nf_cancelada?: string | null
          numero_nota?: number | null
          pedido_cancelado?: string | null
          status?: string | null
          status_prazo_marketplace?: string | null
          status_separacao?: string | null
          transportadora?: string | null
          ultima_atualizacao?: string | null
        }
        Update: {
          andamento?: string | null
          canal?: string | null
          cfop?: string | null
          chavenfe?: string | null
          data_emissao?: string | null
          data_expedicao?: string | null
          data_limite_marketplace?: string | null
          dias_sem_enviar?: number | null
          dthr_separacao?: string | null
          id?: number
          id_expedicao?: number | null
          id_expedicao_previa?: number | null
          id_nota_saida?: number | null
          marketplace_pedido?: string | null
          nf_cancelada?: string | null
          numero_nota?: number | null
          pedido_cancelado?: string | null
          status?: string | null
          status_prazo_marketplace?: string | null
          status_separacao?: string | null
          transportadora?: string | null
          ultima_atualizacao?: string | null
        }
        Relationships: []
      }
      coordenadas_cep: {
        Row: {
          atualizado_em: string
          cep: string
          cidade: string | null
          distancia_km: number | null
          latitude: number | null
          longitude: number | null
          uf: string | null
        }
        Insert: {
          atualizado_em?: string
          cep: string
          cidade?: string | null
          distancia_km?: number | null
          latitude?: number | null
          longitude?: number | null
          uf?: string | null
        }
        Update: {
          atualizado_em?: string
          cep?: string
          cidade?: string | null
          distancia_km?: number | null
          latitude?: number | null
          longitude?: number | null
          uf?: string | null
        }
        Relationships: []
      }
      fato_meta_ia: {
        Row: {
          created_at: string | null
          date: string
          id_produto: number
          marca: string | null
          meta_diaria: number | null
          meta_mes: number | null
          nome_produto: string | null
          subgrupo: string | null
          tem_meta: number | null
        }
        Insert: {
          created_at?: string | null
          date: string
          id_produto: number
          marca?: string | null
          meta_diaria?: number | null
          meta_mes?: number | null
          nome_produto?: string | null
          subgrupo?: string | null
          tem_meta?: number | null
        }
        Update: {
          created_at?: string | null
          date?: string
          id_produto?: number
          marca?: string | null
          meta_diaria?: number | null
          meta_mes?: number | null
          nome_produto?: string | null
          subgrupo?: string | null
          tem_meta?: number | null
        }
        Relationships: []
      }
      fato_repasse_mktp: {
        Row: {
          created_at: string
          id: number
          "pedido-mktp-repasse": string | null
          "repasse-mktp": string | null
        }
        Insert: {
          created_at?: string
          id?: number
          "pedido-mktp-repasse"?: string | null
          "repasse-mktp"?: string | null
        }
        Update: {
          created_at?: string
          id?: number
          "pedido-mktp-repasse"?: string | null
          "repasse-mktp"?: string | null
        }
        Relationships: []
      }
      fato_vendas: {
        Row: {
          ads: number
          ads_loja: number
          ads_loja_percentual: number | null
          ads_percentual: number | null
          aquisicao_shopify_televendas: number
          canal: string | null
          carteira_definitiva: string | null
          created_at: string
          custo_total: number
          custo_unitario: number
          data: string | null
          fantasia: string | null
          faturamento: number
          frete: number
          gasto_afiliado: number
          id_nota_saida: string | null
          id_unico: string
          imposto: number
          ipi: number
          marca: string | null
          margem_percentual: number | null
          margem_reais: number
          nome_produto: string | null
          produto_id: number | null
          quantidade: number
          receita: number
          repasse: number
          shopify_variavel: number
          uf: string | null
          updated_at: string
          vr_produtos: number
        }
        Insert: {
          ads?: number
          ads_loja?: number
          ads_loja_percentual?: number | null
          ads_percentual?: number | null
          aquisicao_shopify_televendas?: number
          canal?: string | null
          carteira_definitiva?: string | null
          created_at?: string
          custo_total?: number
          custo_unitario?: number
          data?: string | null
          fantasia?: string | null
          faturamento?: number
          frete?: number
          gasto_afiliado?: number
          id_nota_saida?: string | null
          id_unico: string
          imposto?: number
          ipi?: number
          marca?: string | null
          margem_percentual?: number | null
          margem_reais?: number
          nome_produto?: string | null
          produto_id?: number | null
          quantidade?: number
          receita?: number
          repasse?: number
          shopify_variavel?: number
          uf?: string | null
          updated_at?: string
          vr_produtos?: number
        }
        Update: {
          ads?: number
          ads_loja?: number
          ads_loja_percentual?: number | null
          ads_percentual?: number | null
          aquisicao_shopify_televendas?: number
          canal?: string | null
          carteira_definitiva?: string | null
          created_at?: string
          custo_total?: number
          custo_unitario?: number
          data?: string | null
          fantasia?: string | null
          faturamento?: number
          frete?: number
          gasto_afiliado?: number
          id_nota_saida?: string | null
          id_unico?: string
          imposto?: number
          ipi?: number
          marca?: string | null
          margem_percentual?: number | null
          margem_reais?: number
          nome_produto?: string | null
          produto_id?: number | null
          quantidade?: number
          receita?: number
          repasse?: number
          shopify_variavel?: number
          uf?: string | null
          updated_at?: string
          vr_produtos?: number
        }
        Relationships: []
      }
      fato_vendas_ia: {
        Row: {
          ads_loja: number | null
          ads_mkt: number | null
          canal_agrupado: string
          created_at: string | null
          date: string
          faturamento: number | null
          id_produto: number
          marca: string | null
          margem_negativa: number | null
          margem_pct: number | null
          margem_rs: number | null
          nome_produto: string | null
          qtd: number | null
          qtd_kits: number | null
          repasse: number | null
        }
        Insert: {
          ads_loja?: number | null
          ads_mkt?: number | null
          canal_agrupado: string
          created_at?: string | null
          date: string
          faturamento?: number | null
          id_produto: number
          marca?: string | null
          margem_negativa?: number | null
          margem_pct?: number | null
          margem_rs?: number | null
          nome_produto?: string | null
          qtd?: number | null
          qtd_kits?: number | null
          repasse?: number | null
        }
        Update: {
          ads_loja?: number | null
          ads_mkt?: number | null
          canal_agrupado?: string
          created_at?: string | null
          date?: string
          faturamento?: number | null
          id_produto?: number
          marca?: string | null
          margem_negativa?: number | null
          margem_pct?: number | null
          margem_rs?: number | null
          nome_produto?: string | null
          qtd?: number | null
          qtd_kits?: number | null
          repasse?: number | null
        }
        Relationships: []
      }
      filter_templates: {
        Row: {
          created_at: string
          created_by: string
          descricao: string | null
          filtros: Json
          id: string
          nome: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by: string
          descricao?: string | null
          filtros?: Json
          id?: string
          nome: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          descricao?: string | null
          filtros?: Json
          id?: string
          nome?: string
          updated_at?: string
        }
        Relationships: []
      }
      flags_config: {
        Row: {
          ativo: boolean
          codigo: string
          cor: string
          created_at: string
          descricao: string | null
          id: string
          label: string
          ordem: number
          threshold: number | null
          tipo: string
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          codigo: string
          cor?: string
          created_at?: string
          descricao?: string | null
          id?: string
          label: string
          ordem?: number
          threshold?: number | null
          tipo: string
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          codigo?: string
          cor?: string
          created_at?: string
          descricao?: string | null
          id?: string
          label?: string
          ordem?: number
          threshold?: number | null
          tipo?: string
          updated_at?: string
        }
        Relationships: []
      }
      formacao_precos_produtos: {
        Row: {
          aliq_ipi: number | null
          altura: number | null
          carteira: string | null
          categoria: string | null
          cod_barra: string | null
          codigo_auxiliar: string | null
          comprimento: number | null
          custo: number | null
          custo_final_calculado: number | null
          custo_formacao: number | null
          data_importacao: string | null
          dt_cadastro: string | null
          grupo_descricao: string | null
          id: number
          id_grupo: number | null
          id_marca: number | null
          id_produto: number | null
          id_subgrupo: number | null
          largura: number | null
          marca_descricao: string | null
          meta_faturamento: string | null
          meta_margem: string | null
          peso_bruto: number | null
          peso_liquido: number | null
          preco_tabela_sysemp: number | null
          produto_comissaoamazon: number | null
          produto_descricao: string | null
          produto_overfrete: number | null
          produto_pma: number | null
          produto_tarifadba: number | null
          qtde_disponivel: number | null
          subgrupo_descricao: string | null
          tipo_calculo: string | null
          tipo_produto_descricao: string | null
        }
        Insert: {
          aliq_ipi?: number | null
          altura?: number | null
          carteira?: string | null
          categoria?: string | null
          cod_barra?: string | null
          codigo_auxiliar?: string | null
          comprimento?: number | null
          custo?: number | null
          custo_final_calculado?: number | null
          custo_formacao?: number | null
          data_importacao?: string | null
          dt_cadastro?: string | null
          grupo_descricao?: string | null
          id?: number
          id_grupo?: number | null
          id_marca?: number | null
          id_produto?: number | null
          id_subgrupo?: number | null
          largura?: number | null
          marca_descricao?: string | null
          meta_faturamento?: string | null
          meta_margem?: string | null
          peso_bruto?: number | null
          peso_liquido?: number | null
          preco_tabela_sysemp?: number | null
          produto_comissaoamazon?: number | null
          produto_descricao?: string | null
          produto_overfrete?: number | null
          produto_pma?: number | null
          produto_tarifadba?: number | null
          qtde_disponivel?: number | null
          subgrupo_descricao?: string | null
          tipo_calculo?: string | null
          tipo_produto_descricao?: string | null
        }
        Update: {
          aliq_ipi?: number | null
          altura?: number | null
          carteira?: string | null
          categoria?: string | null
          cod_barra?: string | null
          codigo_auxiliar?: string | null
          comprimento?: number | null
          custo?: number | null
          custo_final_calculado?: number | null
          custo_formacao?: number | null
          data_importacao?: string | null
          dt_cadastro?: string | null
          grupo_descricao?: string | null
          id?: number
          id_grupo?: number | null
          id_marca?: number | null
          id_produto?: number | null
          id_subgrupo?: number | null
          largura?: number | null
          marca_descricao?: string | null
          meta_faturamento?: string | null
          meta_margem?: string | null
          peso_bruto?: number | null
          peso_liquido?: number | null
          preco_tabela_sysemp?: number | null
          produto_comissaoamazon?: number | null
          produto_descricao?: string | null
          produto_overfrete?: number | null
          produto_pma?: number | null
          produto_tarifadba?: number | null
          qtde_disponivel?: number | null
          subgrupo_descricao?: string | null
          tipo_calculo?: string | null
          tipo_produto_descricao?: string | null
        }
        Relationships: []
      }
      importacoes: {
        Row: {
          created_at: string
          data_importacao: string
          id: string
          nome_arquivo: string | null
          periodo_fim: string | null
          periodo_inicio: string | null
          quantidade_registros: number
          status: string
          tipo_relatorio: string
          usuario_id: string | null
          usuario_nome: string | null
        }
        Insert: {
          created_at?: string
          data_importacao?: string
          id?: string
          nome_arquivo?: string | null
          periodo_fim?: string | null
          periodo_inicio?: string | null
          quantidade_registros?: number
          status?: string
          tipo_relatorio: string
          usuario_id?: string | null
          usuario_nome?: string | null
        }
        Update: {
          created_at?: string
          data_importacao?: string
          id?: string
          nome_arquivo?: string | null
          periodo_fim?: string | null
          periodo_inicio?: string | null
          quantidade_registros?: number
          status?: string
          tipo_relatorio?: string
          usuario_id?: string | null
          usuario_nome?: string | null
        }
        Relationships: []
      }
      itens_sem_repasse: {
        Row: {
          created_at: string | null
          descricao: string | null
          id: string
          id_produto: string
        }
        Insert: {
          created_at?: string | null
          descricao?: string | null
          id?: string
          id_produto: string
        }
        Update: {
          created_at?: string | null
          descricao?: string | null
          id?: string
          id_produto?: string
        }
        Relationships: []
      }
      job_execution_log: {
        Row: {
          error_message: string | null
          execution_id: string
          finished_at: string | null
          finished_at_sp: string | null
          job_name: string | null
          started_at: string
          started_at_sp: string | null
          status: string | null
        }
        Insert: {
          error_message?: string | null
          execution_id?: string
          finished_at?: string | null
          finished_at_sp?: string | null
          job_name?: string | null
          started_at?: string
          started_at_sp?: string | null
          status?: string | null
        }
        Update: {
          error_message?: string | null
          execution_id?: string
          finished_at?: string | null
          finished_at_sp?: string | null
          job_name?: string | null
          started_at?: string
          started_at_sp?: string | null
          status?: string | null
        }
        Relationships: []
      }
      lucrum_campaigns: {
        Row: {
          ativo: boolean
          channel_id: string
          comissao_promo_pct: number
          company_id: string
          created_at: string
          data_fim: string
          data_inicio: string
          desconto_obrigatorio_pct: number
          id: string
          nome: string
          observacoes: string | null
          prioridade: number
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          channel_id: string
          comissao_promo_pct: number
          company_id: string
          created_at?: string
          data_fim: string
          data_inicio: string
          desconto_obrigatorio_pct?: number
          id?: string
          nome: string
          observacoes?: string | null
          prioridade?: number
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          channel_id?: string
          comissao_promo_pct?: number
          company_id?: string
          created_at?: string
          data_fim?: string
          data_inicio?: string
          desconto_obrigatorio_pct?: number
          id?: string
          nome?: string
          observacoes?: string | null
          prioridade?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lucrum_campaigns_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "lucrum_channels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lucrum_campaigns_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "lucrum_companies"
            referencedColumns: ["id"]
          },
        ]
      }
      lucrum_channels: {
        Row: {
          ativo: boolean
          comissao_pct: number
          company_id: string
          created_at: string
          custo_fixo_1: number
          custo_fixo_1_label: string | null
          custo_fixo_2: number
          custo_fixo_2_label: string | null
          custo_var_1_label: string | null
          custo_var_1_pct: number
          custo_var_2_label: string | null
          custo_var_2_pct: number
          frete_medio: number
          id: string
          imposto_pct: number
          is_default: boolean
          nome: string
          taxa_marketplace: number
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          comissao_pct?: number
          company_id: string
          created_at?: string
          custo_fixo_1?: number
          custo_fixo_1_label?: string | null
          custo_fixo_2?: number
          custo_fixo_2_label?: string | null
          custo_var_1_label?: string | null
          custo_var_1_pct?: number
          custo_var_2_label?: string | null
          custo_var_2_pct?: number
          frete_medio?: number
          id?: string
          imposto_pct?: number
          is_default?: boolean
          nome: string
          taxa_marketplace?: number
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          comissao_pct?: number
          company_id?: string
          created_at?: string
          custo_fixo_1?: number
          custo_fixo_1_label?: string | null
          custo_fixo_2?: number
          custo_fixo_2_label?: string | null
          custo_var_1_label?: string | null
          custo_var_1_pct?: number
          custo_var_2_label?: string | null
          custo_var_2_pct?: number
          frete_medio?: number
          id?: string
          imposto_pct?: number
          is_default?: boolean
          nome?: string
          taxa_marketplace?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lucrum_channels_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "lucrum_companies"
            referencedColumns: ["id"]
          },
        ]
      }
      lucrum_companies: {
        Row: {
          created_at: string
          id: string
          nome: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          nome: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          nome?: string
          updated_at?: string
        }
        Relationships: []
      }
      lucrum_company_users: {
        Row: {
          company_id: string
          created_at: string
          id: string
          role: Database["public"]["Enums"]["lucrum_role"]
          user_id: string
        }
        Insert: {
          company_id: string
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["lucrum_role"]
          user_id: string
        }
        Update: {
          company_id?: string
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["lucrum_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lucrum_company_users_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "lucrum_companies"
            referencedColumns: ["id"]
          },
        ]
      }
      lucrum_goals: {
        Row: {
          categoria: string | null
          channel_id: string | null
          company_id: string
          created_at: string
          id: string
          marca: string | null
          meta_faturamento: number | null
          meta_margem_pct: number | null
          periodo_fim: string | null
          periodo_inicio: string | null
          updated_at: string
        }
        Insert: {
          categoria?: string | null
          channel_id?: string | null
          company_id: string
          created_at?: string
          id?: string
          marca?: string | null
          meta_faturamento?: number | null
          meta_margem_pct?: number | null
          periodo_fim?: string | null
          periodo_inicio?: string | null
          updated_at?: string
        }
        Update: {
          categoria?: string | null
          channel_id?: string | null
          company_id?: string
          created_at?: string
          id?: string
          marca?: string | null
          meta_faturamento?: number | null
          meta_margem_pct?: number | null
          periodo_fim?: string | null
          periodo_inicio?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lucrum_goals_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "lucrum_channels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lucrum_goals_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "lucrum_companies"
            referencedColumns: ["id"]
          },
        ]
      }
      lucrum_product_costs: {
        Row: {
          company_id: string
          created_at: string
          custo: number
          data_custo: string
          id: string
          origem: string
          product_id: string
          referencia: string | null
        }
        Insert: {
          company_id: string
          created_at?: string
          custo: number
          data_custo?: string
          id?: string
          origem?: string
          product_id: string
          referencia?: string | null
        }
        Update: {
          company_id?: string
          created_at?: string
          custo?: number
          data_custo?: string
          id?: string
          origem?: string
          product_id?: string
          referencia?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "lucrum_product_costs_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "lucrum_companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lucrum_product_costs_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "lucrum_products"
            referencedColumns: ["id"]
          },
        ]
      }
      lucrum_products: {
        Row: {
          company_id: string
          created_at: string
          id: string
          nome: string
          sku: string
          updated_at: string
        }
        Insert: {
          company_id: string
          created_at?: string
          id?: string
          nome: string
          sku: string
          updated_at?: string
        }
        Update: {
          company_id?: string
          created_at?: string
          id?: string
          nome?: string
          sku?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lucrum_products_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "lucrum_companies"
            referencedColumns: ["id"]
          },
        ]
      }
      lucrum_simulation_items: {
        Row: {
          custo: number
          id: string
          lucro: number
          margem_pct: number
          preco: number
          produto_nome: string | null
          produto_sku: string | null
          quantidade: number
          simulation_id: string
        }
        Insert: {
          custo: number
          id?: string
          lucro: number
          margem_pct: number
          preco: number
          produto_nome?: string | null
          produto_sku?: string | null
          quantidade?: number
          simulation_id: string
        }
        Update: {
          custo?: number
          id?: string
          lucro?: number
          margem_pct?: number
          preco?: number
          produto_nome?: string | null
          produto_sku?: string | null
          quantidade?: number
          simulation_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lucrum_simulation_items_simulation_id_fkey"
            columns: ["simulation_id"]
            isOneToOne: false
            referencedRelation: "lucrum_simulation_logs"
            referencedColumns: ["id"]
          },
        ]
      }
      lucrum_simulation_logs: {
        Row: {
          campaign_id: string | null
          canal_nome: string | null
          channel_id: string | null
          comissao_pct: number
          company_id: string
          created_at: string
          custo: number
          custo_fixo_1: number
          custo_fixo_2: number
          custo_var_1_pct: number
          custo_var_2_pct: number
          erp_id_produto: number | null
          frete_medio: number
          id: string
          imposto_pct: number
          lucro: number
          margem_pct: number
          markup: number
          observacao: string | null
          preco: number
          product_id: string | null
          produto_nome: string | null
          produto_sku: string | null
          taxa_marketplace_pct: number
          user_id: string
        }
        Insert: {
          campaign_id?: string | null
          canal_nome?: string | null
          channel_id?: string | null
          comissao_pct: number
          company_id: string
          created_at?: string
          custo: number
          custo_fixo_1?: number
          custo_fixo_2?: number
          custo_var_1_pct?: number
          custo_var_2_pct?: number
          erp_id_produto?: number | null
          frete_medio?: number
          id?: string
          imposto_pct: number
          lucro: number
          margem_pct: number
          markup: number
          observacao?: string | null
          preco: number
          product_id?: string | null
          produto_nome?: string | null
          produto_sku?: string | null
          taxa_marketplace_pct?: number
          user_id: string
        }
        Update: {
          campaign_id?: string | null
          canal_nome?: string | null
          channel_id?: string | null
          comissao_pct?: number
          company_id?: string
          created_at?: string
          custo?: number
          custo_fixo_1?: number
          custo_fixo_2?: number
          custo_var_1_pct?: number
          custo_var_2_pct?: number
          erp_id_produto?: number | null
          frete_medio?: number
          id?: string
          imposto_pct?: number
          lucro?: number
          margem_pct?: number
          markup?: number
          observacao?: string | null
          preco?: number
          product_id?: string | null
          produto_nome?: string | null
          produto_sku?: string | null
          taxa_marketplace_pct?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lucrum_simulation_logs_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "lucrum_campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lucrum_simulation_logs_channel_id_fkey"
            columns: ["channel_id"]
            isOneToOne: false
            referencedRelation: "lucrum_channels"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lucrum_simulation_logs_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "lucrum_companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lucrum_simulation_logs_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "lucrum_products"
            referencedColumns: ["id"]
          },
        ]
      }
      manifesto_cte: {
        Row: {
          chave_nfe_referenciada: string
          created_at: string
          data_emissao_cte: string | null
          id: string
          importacao_id: string | null
          numero_cte: string | null
          peso_cte: number | null
          transportadora_cte: string | null
          updated_at: string
          valor_cte: number | null
        }
        Insert: {
          chave_nfe_referenciada: string
          created_at?: string
          data_emissao_cte?: string | null
          id?: string
          importacao_id?: string | null
          numero_cte?: string | null
          peso_cte?: number | null
          transportadora_cte?: string | null
          updated_at?: string
          valor_cte?: number | null
        }
        Update: {
          chave_nfe_referenciada?: string
          created_at?: string
          data_emissao_cte?: string | null
          id?: string
          importacao_id?: string | null
          numero_cte?: string | null
          peso_cte?: number | null
          transportadora_cte?: string | null
          updated_at?: string
          valor_cte?: number | null
        }
        Relationships: []
      }
      mapeamento_colunas: {
        Row: {
          created_at: string
          id: string
          mapeamento: Json
          nome: string
          padrao: boolean
          tipo_relatorio: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          mapeamento?: Json
          nome: string
          padrao?: boolean
          tipo_relatorio: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          mapeamento?: Json
          nome?: string
          padrao?: boolean
          tipo_relatorio?: string
          updated_at?: string
        }
        Relationships: []
      }
      metricas_personalizadas: {
        Row: {
          ativo: boolean | null
          campo_valor: string
          created_at: string | null
          deduplicar_por_campo: string | null
          descricao: string | null
          destino_visualizacao: string[] | null
          dimensao_grafico: string | null
          filtros_exclusao_nat_operacao: Json | null
          filtros_inclusao_nat_operacao: Json | null
          formula_calculo: Json | null
          id: string
          nat_operacao_inverter_sinal: Json | null
          nome_metrica: string
          tipo_agregacao: string
          tipo_visualizacao: Json | null
          updated_at: string | null
        }
        Insert: {
          ativo?: boolean | null
          campo_valor: string
          created_at?: string | null
          deduplicar_por_campo?: string | null
          descricao?: string | null
          destino_visualizacao?: string[] | null
          dimensao_grafico?: string | null
          filtros_exclusao_nat_operacao?: Json | null
          filtros_inclusao_nat_operacao?: Json | null
          formula_calculo?: Json | null
          id?: string
          nat_operacao_inverter_sinal?: Json | null
          nome_metrica: string
          tipo_agregacao: string
          tipo_visualizacao?: Json | null
          updated_at?: string | null
        }
        Update: {
          ativo?: boolean | null
          campo_valor?: string
          created_at?: string | null
          deduplicar_por_campo?: string | null
          descricao?: string | null
          destino_visualizacao?: string[] | null
          dimensao_grafico?: string | null
          filtros_exclusao_nat_operacao?: Json | null
          filtros_inclusao_nat_operacao?: Json | null
          formula_calculo?: Json | null
          id?: string
          nat_operacao_inverter_sinal?: Json | null
          nome_metrica?: string
          tipo_agregacao?: string
          tipo_visualizacao?: Json | null
          updated_at?: string | null
        }
        Relationships: []
      }
      notas_saida: {
        Row: {
          created_at: string
          id: number
          id_empresa: number
          payload: Json
          tipoconsulta: string
        }
        Insert: {
          created_at?: string
          id?: number
          id_empresa: number
          payload: Json
          tipoconsulta: string
        }
        Update: {
          created_at?: string
          id?: number
          id_empresa?: number
          payload?: Json
          tipoconsulta?: string
        }
        Relationships: []
      }
      produto_estado_atual: {
        Row: {
          dthr_atualizacao: string | null
          id_marca: number | null
          id_produto: number
          id_subgrupo: number | null
          last_snapshot_at: string
          marca_descricao: string | null
          produto_carteira_marca: string | null
          produto_carteira_por_produto: string | null
          produto_descricao: string | null
          produto_meta_faturamento: string | null
          produto_meta_margem: string | null
          produto_pma: string | null
          subgrupo_descricao: string | null
          us_alteracao: string | null
        }
        Insert: {
          dthr_atualizacao?: string | null
          id_marca?: number | null
          id_produto: number
          id_subgrupo?: number | null
          last_snapshot_at?: string
          marca_descricao?: string | null
          produto_carteira_marca?: string | null
          produto_carteira_por_produto?: string | null
          produto_descricao?: string | null
          produto_meta_faturamento?: string | null
          produto_meta_margem?: string | null
          produto_pma?: string | null
          subgrupo_descricao?: string | null
          us_alteracao?: string | null
        }
        Update: {
          dthr_atualizacao?: string | null
          id_marca?: number | null
          id_produto?: number
          id_subgrupo?: number | null
          last_snapshot_at?: string
          marca_descricao?: string | null
          produto_carteira_marca?: string | null
          produto_carteira_por_produto?: string | null
          produto_descricao?: string | null
          produto_meta_faturamento?: string | null
          produto_meta_margem?: string | null
          produto_pma?: string | null
          subgrupo_descricao?: string | null
          us_alteracao?: string | null
        }
        Relationships: []
      }
      produto_event_log: {
        Row: {
          campo_alterado: string
          data_origem_erp: string | null
          data_origem_erp_sp: string | null
          event_id: string
          id_produto: number
          snapshot_at: string
          snapshot_at_sp: string | null
          usuario_alteracao: string | null
          valor_anterior: string | null
          valor_novo: string | null
        }
        Insert: {
          campo_alterado: string
          data_origem_erp?: string | null
          data_origem_erp_sp?: string | null
          event_id?: string
          id_produto: number
          snapshot_at?: string
          snapshot_at_sp?: string | null
          usuario_alteracao?: string | null
          valor_anterior?: string | null
          valor_novo?: string | null
        }
        Update: {
          campo_alterado?: string
          data_origem_erp?: string | null
          data_origem_erp_sp?: string | null
          event_id?: string
          id_produto?: number
          snapshot_at?: string
          snapshot_at_sp?: string | null
          usuario_alteracao?: string | null
          valor_anterior?: string | null
          valor_novo?: string | null
        }
        Relationships: []
      }
      produto_snapshot: {
        Row: {
          dthr_atualizacao: string | null
          id_produto: number
          produto_carteira_marca: string | null
          produto_carteira_por_produto: string | null
          produto_pma: string | null
          produto_produto_meta_faturamento: string | null
          produto_produto_meta_margem: string | null
          snapshot_at: string
          snapshot_id: string
          us_alteracao: string | null
        }
        Insert: {
          dthr_atualizacao?: string | null
          id_produto: number
          produto_carteira_marca?: string | null
          produto_carteira_por_produto?: string | null
          produto_pma?: string | null
          produto_produto_meta_faturamento?: string | null
          produto_produto_meta_margem?: string | null
          snapshot_at?: string
          snapshot_id?: string
          us_alteracao?: string | null
        }
        Update: {
          dthr_atualizacao?: string | null
          id_produto?: number
          produto_carteira_marca?: string | null
          produto_carteira_por_produto?: string | null
          produto_pma?: string | null
          produto_produto_meta_faturamento?: string | null
          produto_produto_meta_margem?: string | null
          snapshot_at?: string
          snapshot_id?: string
          us_alteracao?: string | null
        }
        Relationships: []
      }
      produto_snapshot_current_job: {
        Row: {
          dthr_atualizacao: string | null
          id_marca: number | null
          id_produto: number
          id_subgrupo: number | null
          marca_descricao: string | null
          produto_carteira_marca: string | null
          produto_carteira_por_produto: string | null
          produto_descricao: string | null
          produto_pma: string | null
          produto_produto_meta_faturamento: string | null
          produto_produto_meta_margem: string | null
          snapshot_at: string
          subgrupo_descricao: string | null
          us_alteracao: string | null
        }
        Insert: {
          dthr_atualizacao?: string | null
          id_marca?: number | null
          id_produto: number
          id_subgrupo?: number | null
          marca_descricao?: string | null
          produto_carteira_marca?: string | null
          produto_carteira_por_produto?: string | null
          produto_descricao?: string | null
          produto_pma?: string | null
          produto_produto_meta_faturamento?: string | null
          produto_produto_meta_margem?: string | null
          snapshot_at?: string
          subgrupo_descricao?: string | null
          us_alteracao?: string | null
        }
        Update: {
          dthr_atualizacao?: string | null
          id_marca?: number | null
          id_produto?: number
          id_subgrupo?: number | null
          marca_descricao?: string | null
          produto_carteira_marca?: string | null
          produto_carteira_por_produto?: string | null
          produto_descricao?: string | null
          produto_pma?: string | null
          produto_produto_meta_faturamento?: string | null
          produto_produto_meta_margem?: string | null
          snapshot_at?: string
          subgrupo_descricao?: string | null
          us_alteracao?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          id: string
          nome: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          id?: string
          nome?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          id?: string
          nome?: string | null
          user_id?: string
        }
        Relationships: []
      }
      regras_governanca: {
        Row: {
          ativo: boolean | null
          created_at: string | null
          id: number
          regra_nome: string
          tipo_regra: string
          valor_regra: string
        }
        Insert: {
          ativo?: boolean | null
          created_at?: string | null
          id?: number
          regra_nome: string
          tipo_regra: string
          valor_regra: string
        }
        Update: {
          ativo?: boolean | null
          created_at?: string | null
          id?: number
          regra_nome?: string
          tipo_regra?: string
          valor_regra?: string
        }
        Relationships: []
      }
      relatorio_base_nf: {
        Row: {
          canal_venda: string | null
          cep_destino: string | null
          chave_nfe: string
          cidade_destino: string | null
          created_at: string
          cubagem: number | null
          data_emissao: string | null
          data_entrega: string | null
          id: string
          importacao_id: string | null
          numero_nf: string | null
          pedido_marketplace: string | null
          peso: number | null
          previsao_entrega: string | null
          produto: string | null
          quantidade: number | null
          transportadora: string | null
          uf_destino: string | null
          updated_at: string
          valor_frete_cliente: number | null
          valor_item_liquido: number | null
          valor_nf_total: number | null
          valor_unitario: number | null
        }
        Insert: {
          canal_venda?: string | null
          cep_destino?: string | null
          chave_nfe: string
          cidade_destino?: string | null
          created_at?: string
          cubagem?: number | null
          data_emissao?: string | null
          data_entrega?: string | null
          id?: string
          importacao_id?: string | null
          numero_nf?: string | null
          pedido_marketplace?: string | null
          peso?: number | null
          previsao_entrega?: string | null
          produto?: string | null
          quantidade?: number | null
          transportadora?: string | null
          uf_destino?: string | null
          updated_at?: string
          valor_frete_cliente?: number | null
          valor_item_liquido?: number | null
          valor_nf_total?: number | null
          valor_unitario?: number | null
        }
        Update: {
          canal_venda?: string | null
          cep_destino?: string | null
          chave_nfe?: string
          cidade_destino?: string | null
          created_at?: string
          cubagem?: number | null
          data_emissao?: string | null
          data_entrega?: string | null
          id?: string
          importacao_id?: string | null
          numero_nf?: string | null
          pedido_marketplace?: string | null
          peso?: number | null
          previsao_entrega?: string | null
          produto?: string | null
          quantidade?: number | null
          transportadora?: string | null
          uf_destino?: string | null
          updated_at?: string
          valor_frete_cliente?: number | null
          valor_item_liquido?: number | null
          valor_nf_total?: number | null
          valor_unitario?: number | null
        }
        Relationships: []
      }
      tv_dashboards: {
        Row: {
          ativo: boolean | null
          created_at: string | null
          descricao: string | null
          id: string
          imagem_url: string
          link_powerbi: string | null
          modo_exibicao: string
          nome: string
          ordem: number | null
          ultima_atualizacao: string | null
        }
        Insert: {
          ativo?: boolean | null
          created_at?: string | null
          descricao?: string | null
          id?: string
          imagem_url: string
          link_powerbi?: string | null
          modo_exibicao?: string
          nome: string
          ordem?: number | null
          ultima_atualizacao?: string | null
        }
        Update: {
          ativo?: boolean | null
          created_at?: string | null
          descricao?: string | null
          id?: string
          imagem_url?: string
          link_powerbi?: string | null
          modo_exibicao?: string
          nome?: string
          ordem?: number | null
          ultima_atualizacao?: string | null
        }
        Relationships: []
      }
      tv_expedicao_pendente: {
        Row: {
          andamento_descricao: string | null
          canal_venda: string | null
          data_emissao: string | null
          dthr_separacao: string | null
          id: string
          numero_nota: string
          serie_nota: string | null
          status_expedicao: string
          transportadora: string
          ultima_atualizacao: string | null
        }
        Insert: {
          andamento_descricao?: string | null
          canal_venda?: string | null
          data_emissao?: string | null
          dthr_separacao?: string | null
          id?: string
          numero_nota: string
          serie_nota?: string | null
          status_expedicao: string
          transportadora: string
          ultima_atualizacao?: string | null
        }
        Update: {
          andamento_descricao?: string | null
          canal_venda?: string | null
          data_emissao?: string | null
          dthr_separacao?: string | null
          id?: string
          numero_nota?: string
          serie_nota?: string | null
          status_expedicao?: string
          transportadora?: string
          ultima_atualizacao?: string | null
        }
        Relationships: []
      }
      tv_relatorios: {
        Row: {
          ativo: boolean
          created_at: string
          id: string
          ordem: number
          relatorio_id: string
          tv_id: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          id?: string
          ordem?: number
          relatorio_id: string
          tv_id: string
        }
        Update: {
          ativo?: boolean
          created_at?: string
          id?: string
          ordem?: number
          relatorio_id?: string
          tv_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tv_relatorios_relatorio_id_fkey"
            columns: ["relatorio_id"]
            isOneToOne: false
            referencedRelation: "tv_dashboards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tv_relatorios_tv_id_fkey"
            columns: ["tv_id"]
            isOneToOne: false
            referencedRelation: "tvs"
            referencedColumns: ["id"]
          },
        ]
      }
      tvs: {
        Row: {
          ativo: boolean
          created_at: string
          id: string
          intervalo_segundos: number
          nome: string
          slug: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          id?: string
          intervalo_segundos?: number
          nome: string
          slug: string
        }
        Update: {
          ativo?: boolean
          created_at?: string
          id?: string
          intervalo_segundos?: number
          nome?: string
          slug?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      controle_envios_nf: {
        Row: {
          andamento: string | null
          canal: string | null
          cfop: string | null
          chavenfe: string | null
          data_emissao: string | null
          data_expedicao: string | null
          data_limite_marketplace: string | null
          dias_sem_enviar: number | null
          dthr_separacao: string | null
          id: number | null
          id_expedicao: number | null
          id_expedicao_previa: number | null
          id_nota_saida: number | null
          marketplace_pedido: string | null
          nf_cancelada: string | null
          pedido_cancelado: string | null
          status: string | null
          status_prazo_marketplace: string | null
          status_separacao: string | null
          transportadora: string | null
          ultima_atualizacao: string | null
        }
        Relationships: []
      }
      mv_analytics_final: {
        Row: {
          canal_venda: string | null
          custo_produto: number | null
          custo_total_nota: number | null
          data_emissao: string | null
          id_nota_saida: string | null
          id_produto: string | null
          item_quantidade: number | null
          item_total_liquido: number | null
          item_valor_unitario: number | null
          itens_array: Json | null
          marketplace_pedido: string | null
          mv_row_id: number | null
          nat_operacao: string | null
          nf_cancelada: boolean | null
          numero_nota: string | null
          produto_descricao: string | null
          produto_marca: string | null
          "repasse-mktp": number | null
          status_descricao: string | null
          valor_frete: number | null
          valor_total_nota: number | null
        }
        Relationships: []
      }
      mv_produto_meta_faturamento_mensal: {
        Row: {
          data_origem_erp: string | null
          id_produto: number | null
          mes_referencia: string | null
          produto_meta_faturamento: number | null
        }
        Relationships: []
      }
      mv_produto_meta_margem_mensal: {
        Row: {
          data_origem_erp: string | null
          id_produto: number | null
          mes_referencia: string | null
          produto_meta_margem: number | null
        }
        Relationships: []
      }
      notas_saida_organizada: {
        Row: {
          id_nota_saida: string | null
          transportadora: string | null
        }
        Relationships: []
      }
      vw_analytics_final: {
        Row: {
          canal_venda: string | null
          custo_produto: number | null
          custo_total_nota: number | null
          data_emissao: string | null
          id_nota_saida: string | null
          id_produto: string | null
          item_quantidade: number | null
          item_total_liquido: number | null
          item_valor_unitario: number | null
          itens_array: Json | null
          marketplace_pedido: string | null
          nat_operacao: string | null
          nf_cancelada: boolean | null
          numero_nota: string | null
          produto_descricao: string | null
          produto_marca: string | null
          "repasse-mktp": number | null
          status_descricao: string | null
          valor_frete: number | null
          valor_total_nota: number | null
        }
        Relationships: []
      }
      vw_analytics_repasse_item: {
        Row: {
          canal_venda: string | null
          custo_produto: number | null
          custo_total_nota: number | null
          data_emissao: string | null
          id_nota_saida: string | null
          id_produto: string | null
          item_quantidade: number | null
          item_total_liquido: number | null
          item_valor_unitario: number | null
          itens_array: Json | null
          marketplace_pedido: string | null
          nat_operacao: string | null
          nf_cancelada: boolean | null
          numero_nota: string | null
          produto_descricao: string | null
          produto_marca: string | null
          repasse_item_proporcional: number | null
          "repasse-mktp": number | null
          status_descricao: string | null
          valor_frete: number | null
          valor_total_nota: number | null
        }
        Relationships: []
      }
      vw_notas_saida_expanded: {
        Row: {
          canal_venda: string | null
          custo_total_nota: number | null
          data_emissao: string | null
          id_nota_saida: string | null
          itens_array: Json | null
          marketplace_pedido: string | null
          nat_operacao: string | null
          nf_cancelada: boolean | null
          numero_nota: string | null
          "repasse-mktp": number | null
          status_descricao: string | null
          valor_frete: number | null
          valor_total_nota: number | null
        }
        Relationships: []
      }
      vw_notas_saida_items: {
        Row: {
          canal_venda: string | null
          custo_produto: number | null
          custo_total_nota: number | null
          data_emissao: string | null
          id_nota_saida: string | null
          id_produto: string | null
          item_quantidade: number | null
          item_total_liquido: number | null
          item_valor_unitario: number | null
          itens_array: Json | null
          marketplace_pedido: string | null
          nat_operacao: string | null
          nf_cancelada: boolean | null
          numero_nota: string | null
          produto_descricao: string | null
          produto_marca: string | null
          "repasse-mktp": number | null
          status_descricao: string | null
          valor_frete: number | null
          valor_total_nota: number | null
        }
        Relationships: []
      }
      vw_produto_subgrupo: {
        Row: {
          id_produto: number | null
          marca: string | null
          nome_produto: string | null
          subgrupo: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      analytics_comparativo: {
        Args: {
          p_canais?: string[]
          p_fim: string
          p_inicio: string
          p_marcas?: string[]
          p_modo?: string
          p_produtos?: number[]
          p_subgrupos?: string[]
        }
        Returns: {
          anterior: number
          atual: number
          delta_pct: number
          metrica: string
        }[]
      }
      analytics_dimensoes_disponiveis: { Args: never; Returns: Json }
      analytics_kpis: {
        Args: {
          p_canais?: string[]
          p_fim: string
          p_inicio: string
          p_marcas?: string[]
          p_produtos?: number[]
          p_subgrupos?: string[]
        }
        Returns: {
          ads_loja: number
          ads_mkt: number
          ads_total: number
          atingimento_pct: number
          dias_com_meta: number
          dias_com_venda: number
          faturamento: number
          gap_meta_rs: number
          margem_negativa_rs: number
          margem_pct: number
          margem_rs: number
          meta_periodo: number
          produtos_com_meta: number
          produtos_distintos: number
          qtd: number
          qtd_kits: number
          repasse: number
          roas: number
          ticket_medio: number
        }[]
      }
      analytics_meta_por_produto: {
        Args: {
          p_canais?: string[]
          p_fim: string
          p_inicio: string
          p_limit?: number
          p_marcas?: string[]
          p_only_with_meta?: boolean
          p_produtos?: number[]
          p_subgrupos?: string[]
        }
        Returns: {
          atingimento_pct: number
          gap_rs: number
          id_produto: number
          marca: string
          meta: number
          nome_produto: string
          qtd: number
          realizado: number
          subgrupo: string
        }[]
      }
      analytics_meta_vs_real: {
        Args: {
          p_canais?: string[]
          p_dim?: string
          p_fim: string
          p_inicio: string
          p_marcas?: string[]
          p_produtos?: number[]
          p_subgrupos?: string[]
        }
        Returns: {
          atingimento_pct: number
          chave: string
          dias_com_venda: number
          dias_no_periodo: number
          dias_restantes: number
          gap_rs: number
          meta_periodo: number
          produtos_com_meta: number
          projecao_atingimento_pct: number
          projecao_fechamento: number
          realizado_periodo: number
        }[]
      }
      analytics_por_dimensao: {
        Args: {
          p_canais?: string[]
          p_dim: string
          p_fim: string
          p_inicio: string
          p_limit?: number
          p_marcas?: string[]
          p_produtos?: number[]
          p_subgrupos?: string[]
        }
        Returns: {
          ads_total: number
          chave: string
          faturamento: number
          margem_pct: number
          margem_rs: number
          participacao_pct: number
          qtd: number
        }[]
      }
      analytics_serie_diaria: {
        Args: {
          p_canais?: string[]
          p_fim: string
          p_inicio: string
          p_marcas?: string[]
          p_produtos?: number[]
          p_subgrupos?: string[]
        }
        Returns: {
          ads_total: number
          dia: string
          faturamento: number
          margem_pct: number
          margem_rs: number
          qtd: number
        }[]
      }
      analytics_top_produtos: {
        Args: {
          p_asc?: boolean
          p_canais?: string[]
          p_fim: string
          p_inicio: string
          p_limit?: number
          p_marcas?: string[]
          p_order_by?: string
          p_subgrupos?: string[]
        }
        Returns: {
          ads_total: number
          faturamento: number
          id_produto: number
          marca: string
          margem_pct: number
          margem_rs: number
          nome_produto: string
          qtd: number
          roas: number
        }[]
      }
      aplicar_view: { Args: { p_sql: string }; Returns: undefined }
      chat_listar_dimensoes: {
        Args: { p_dim: string }
        Returns: {
          valor: string
        }[]
      }
      chat_periodo_disponivel: {
        Args: never
        Returns: {
          data_max: string
          data_min: string
          total_registros: number
        }[]
      }
      chat_query_vendas: {
        Args: {
          p_canal?: string
          p_data_fim?: string
          p_data_inicio?: string
          p_group_by?: string
          p_limit?: number
          p_marca?: string
          p_order_by?: string
          p_produto_id?: number
          p_subgrupo?: string
        }
        Returns: {
          ads_total: number
          atingimento_pct: number
          chave: string
          faturamento: number
          grupo: string
          id_produto: string
          marca: string
          margem_percentual: number
          margem_reais: number
          meta_periodo: number
          qtd_kits: number
          quantidade: number
          repasse: number
        }[]
      }
      get_analise_por_item: {
        Args: {
          p_limit?: number
          p_offset?: number
          p_status_conciliacao?: string
        }
        Returns: {
          custo_frete: number
          custo_item_km: number
          frete_cliente: number
          margem: number
          over_frete: number
          over_percentual: number
          perc_frete: number
          produto: string
          qtd_itens: number
          valor_total: number
        }[]
      }
      get_analise_por_nota: {
        Args: {
          p_canal_venda?: string
          p_cep_max?: string
          p_cep_min?: string
          p_chave_nfe?: string
          p_cidade_destino?: string
          p_data_emissao_fim?: string
          p_data_emissao_inicio?: string
          p_distancia_km_max?: number
          p_distancia_km_min?: number
          p_frete_cliente_max?: number
          p_frete_cliente_min?: number
          p_frete_cte_max?: number
          p_frete_cte_min?: number
          p_limit?: number
          p_numero_nf?: string
          p_offset?: number
          p_over_max?: number
          p_over_min?: number
          p_status_conciliacao?: string
          p_transportadoras?: string[]
          p_ufs?: string[]
          p_valor_nf_max?: number
          p_valor_nf_min?: number
        }
        Returns: {
          chave_nfe: string
          custo_km: number
          data_emissao: string
          distancia_km: number
          frete_cliente: number
          frete_cte: number
          indice_frete_valor: number
          numero_cte: string
          numero_nf: string
          over_frete: number
          over_percentual: number
          transportadora: string
          valor_nf: number
        }[]
      }
      get_analise_por_nota_count: {
        Args: {
          p_canal_venda?: string
          p_cep_max?: string
          p_cep_min?: string
          p_chave_nfe?: string
          p_cidade_destino?: string
          p_data_emissao_fim?: string
          p_data_emissao_inicio?: string
          p_distancia_km_max?: number
          p_distancia_km_min?: number
          p_frete_cliente_max?: number
          p_frete_cliente_min?: number
          p_frete_cte_max?: number
          p_frete_cte_min?: number
          p_numero_nf?: string
          p_over_max?: number
          p_over_min?: number
          p_status_conciliacao?: string
          p_transportadoras?: string[]
          p_ufs?: string[]
          p_valor_nf_max?: number
          p_valor_nf_min?: number
        }
        Returns: number
      }
      get_analise_por_transportadora: {
        Args: {
          p_canal_venda?: string
          p_cep_max?: string
          p_cep_min?: string
          p_chave_nfe?: string
          p_cidade_destino?: string
          p_data_emissao_fim?: string
          p_data_emissao_inicio?: string
          p_distancia_km_max?: number
          p_distancia_km_min?: number
          p_frete_cliente_max?: number
          p_frete_cliente_min?: number
          p_frete_cte_max?: number
          p_frete_cte_min?: number
          p_numero_nf?: string
          p_over_max?: number
          p_over_min?: number
          p_status_conciliacao?: string
          p_transportadoras?: string[]
          p_ufs?: string[]
          p_valor_nf_max?: number
          p_valor_nf_min?: number
        }
        Returns: {
          custo_medio: number
          custo_medio_km: number
          distancia_media: number
          frete_cliente: number
          frete_cte: number
          indice_frete_valor: number
          over_frete: number
          over_percentual: number
          prazo_medio: number
          total_notas: number
          transportadora: string
        }[]
      }
      get_ceps_pendentes: {
        Args: { p_limit?: number }
        Returns: {
          cep: string
          cidade: string
          uf: string
        }[]
      }
      get_channel_aggregation: {
        Args: {
          p_canal?: string
          p_end_date?: string
          p_marca?: string
          p_window_days?: number
        }
        Returns: {
          canal: string
          faturamento_anterior: number
          faturamento_total: number
          flags: string[]
          margem_pct: number
          margem_pct_anterior: number
          margem_total: number
          pedidos_total: number
          receita_total: number
          variacao_faturamento: number
        }[]
      }
      get_conciliation_delta: { Args: never; Returns: Json }
      get_custom_metric:
        | {
            Args: {
              p_campo_valor: string
              p_data_fim?: string
              p_data_inicio?: string
              p_deduplicar_por_campo?: string
              p_excluir_nat_op?: string[]
              p_filtro_canal?: string
              p_filtro_marca?: string
              p_filtro_status?: string
              p_incluir_nat_op?: string[]
              p_inverter_sinal_nat_op?: string[]
              p_tipo_agregacao: string
            }
            Returns: number
          }
        | {
            Args: {
              p_campo_valor: string
              p_data_fim?: string
              p_data_inicio?: string
              p_deduplicar_por_campo?: string
              p_excluir_nat_op?: string[]
              p_filtro_canal?: string
              p_filtro_marca?: string
              p_filtro_marketplace_pedido?: string
              p_filtro_numero_nota?: string
              p_filtro_status?: string
              p_incluir_nat_op?: string[]
              p_inverter_sinal_nat_op?: string[]
              p_tipo_agregacao: string
            }
            Returns: number
          }
      get_custom_metric_series:
        | {
            Args: {
              p_campo_valor: string
              p_data_fim?: string
              p_data_inicio?: string
              p_deduplicar_por_campo?: string
              p_dimensao?: string
              p_excluir_nat_op?: string[]
              p_filtro_canal?: string
              p_filtro_marca?: string
              p_filtro_status?: string
              p_incluir_nat_op?: string[]
              p_inverter_sinal_nat_op?: string[]
              p_limit_rows?: number
              p_tipo_agregacao: string
            }
            Returns: {
              dimensao: string
              valor: number
            }[]
          }
        | {
            Args: {
              p_campo_valor: string
              p_data_fim?: string
              p_data_inicio?: string
              p_deduplicar_por_campo?: string
              p_dimensao?: string
              p_excluir_nat_op?: string[]
              p_filtro_canal?: string
              p_filtro_marca?: string
              p_filtro_marketplace_pedido?: string
              p_filtro_numero_nota?: string
              p_filtro_status?: string
              p_incluir_nat_op?: string[]
              p_inverter_sinal_nat_op?: string[]
              p_limit_rows?: number
              p_tipo_agregacao: string
            }
            Returns: {
              dimensao: string
              valor: number
            }[]
          }
      get_dashboard_kpis: {
        Args: {
          p_canal_venda?: string
          p_cep_max?: string
          p_cep_min?: string
          p_chave_nfe?: string
          p_cidade_destino?: string
          p_data_emissao_fim?: string
          p_data_emissao_inicio?: string
          p_distancia_km_max?: number
          p_distancia_km_min?: number
          p_frete_cliente_max?: number
          p_frete_cliente_min?: number
          p_frete_cte_max?: number
          p_frete_cte_min?: number
          p_numero_nf?: string
          p_over_max?: number
          p_over_min?: number
          p_status_conciliacao?: string
          p_transportadoras?: string[]
          p_ufs?: string[]
          p_valor_nf_max?: number
          p_valor_nf_min?: number
        }
        Returns: Json
      }
      get_distinct_values: {
        Args: { p_column_name: string }
        Returns: {
          value: string
        }[]
      }
      get_expedicao_filter_options: { Args: never; Returns: Json }
      get_expedicao_kpis:
        | {
            Args: {
              p_andamentos?: string[]
              p_apenas_expedidos?: boolean
              p_apenas_nao_expedidos?: boolean
              p_apenas_nao_separados?: boolean
              p_busca_global?: string
              p_canais?: string[]
              p_cfops?: string[]
              p_data_fim?: string
              p_data_inicio?: string
              p_pedido_cancelado?: string
              p_status_prazos?: string[]
              p_transportadoras?: string[]
            }
            Returns: Json
          }
        | {
            Args: {
              p_andamentos?: string[]
              p_apenas_nao_expedidos?: boolean
              p_apenas_nao_separados?: boolean
              p_busca_global?: string
              p_canais?: string[]
              p_cfops?: string[]
              p_data_fim?: string
              p_data_inicio?: string
              p_status_prazos?: string[]
              p_transportadoras?: string[]
            }
            Returns: Json
          }
        | {
            Args: {
              p_andamentos?: string[]
              p_apenas_nao_expedidos?: boolean
              p_apenas_nao_separados?: boolean
              p_busca_global?: string
              p_canais?: string[]
              p_cfops?: string[]
              p_data_fim?: string
              p_data_inicio?: string
              p_pedido_cancelado?: string
              p_status_prazos?: string[]
              p_transportadoras?: string[]
            }
            Returns: Json
          }
      get_filter_options: { Args: never; Returns: Json }
      get_integrity_check: { Args: never; Returns: Json }
      get_mapa_logistico: {
        Args: {
          p_canal_venda?: string
          p_cep_max?: string
          p_cep_min?: string
          p_chave_nfe?: string
          p_cidade_destino?: string
          p_data_emissao_fim?: string
          p_data_emissao_inicio?: string
          p_distancia_km_max?: number
          p_distancia_km_min?: number
          p_frete_cliente_max?: number
          p_frete_cliente_min?: number
          p_frete_cte_max?: number
          p_frete_cte_min?: number
          p_numero_nf?: string
          p_over_max?: number
          p_over_min?: number
          p_status_conciliacao?: string
          p_transportadoras?: string[]
          p_ufs?: string[]
          p_valor_nf_max?: number
          p_valor_nf_min?: number
        }
        Returns: {
          cep: string
          cidade: string
          custo_km: number
          distancia_km: number
          latitude: number
          longitude: number
          over_percentual: number
          total_frete: number
          total_notas: number
          total_over: number
          uf: string
        }[]
      }
      get_notas_agregadas: {
        Args: {
          p_data_fim?: string
          p_data_inicio?: string
          p_filtro_canal?: string
          p_filtro_marca?: string
          p_filtro_marketplace_pedido?: string
          p_filtro_numero_nota?: string
          p_filtro_status?: string
          p_limit?: number
          p_offset?: number
        }
        Returns: {
          canal_venda: string
          custo_produto_total: number
          data_emissao: string
          marketplace_pedido: string
          numero_nota: string
          qtde_itens: number
          repasse_liquido: number
          transportadora: string
          valor_frete: number
          valor_total_nota: number
        }[]
      }
      get_notas_agregadas_count: {
        Args: {
          p_data_fim?: string
          p_data_inicio?: string
          p_filtro_canal?: string
          p_filtro_marca?: string
          p_filtro_marketplace_pedido?: string
          p_filtro_numero_nota?: string
          p_filtro_status?: string
        }
        Returns: number
      }
      get_product_aggregation: {
        Args: {
          p_canal?: string
          p_end_date?: string
          p_marca?: string
          p_window_days?: number
        }
        Returns: {
          carteira_marca: string
          carteira_produto: string
          faturamento_total: number
          marca: string
          margem_pct: number
          margem_total: number
          nome_produto: string
          pedidos_total: number
          produto_id: number
          quantidade_total: number
          receita_total: number
        }[]
      }
      get_product_window_comparison: {
        Args: {
          p_canal?: string
          p_end_date?: string
          p_marca?: string
          p_window_days?: number
        }
        Returns: {
          carteira_marca: string
          carteira_produto: string
          faturamento_anterior: number
          faturamento_atual: number
          flags: string[]
          marca: string
          margem_atual: number
          margem_pct_anterior: number
          margem_pct_atual: number
          nome_produto: string
          produto_id: number
          variacao_faturamento: number
        }[]
      }
      get_produtos_agregados:
        | {
            Args: {
              p_data_fim?: string
              p_data_inicio?: string
              p_filtro_canal?: string
              p_filtro_marca?: string
              p_filtro_marketplace_pedido?: string
              p_filtro_numero_nota?: string
              p_filtro_status?: string
              p_limit?: number
              p_offset?: number
            }
            Returns: {
              custo_total: number
              id_produto: string
              produto_descricao: string
              produto_marca: string
              quantidade_total: number
              repasse_medio_unidade: number
              repasse_total: number
              total_notas: number
              venda_liquida_total: number
            }[]
          }
        | {
            Args: {
              p_data_fim?: string
              p_data_inicio?: string
              p_filtro_canal?: string
              p_filtro_marca?: string
              p_filtro_numero_nota?: string
              p_limit?: number
              p_offset?: number
            }
            Returns: {
              custo_total: number
              id_produto: string
              produto_descricao: string
              produto_marca: string
              quantidade_total: number
              repasse_medio_unidade: number
              repasse_total: number
              total_notas: number
              venda_liquida_total: number
            }[]
          }
        | {
            Args: {
              p_data_fim?: string
              p_data_inicio?: string
              p_filtro_canal?: string
              p_filtro_marca?: string
              p_limit?: number
              p_offset?: number
            }
            Returns: {
              id_produto: string
              produto_descricao: string
              produto_marca: string
              quantidade_total: number
              repasse_medio_unidade: number
              repasse_total: number
              total_notas: number
              venda_liquida_total: number
            }[]
          }
      get_produtos_agregados_count:
        | {
            Args: {
              p_data_fim?: string
              p_data_inicio?: string
              p_filtro_canal?: string
              p_filtro_marca?: string
            }
            Returns: number
          }
        | {
            Args: {
              p_data_fim?: string
              p_data_inicio?: string
              p_filtro_canal?: string
              p_filtro_marca?: string
              p_filtro_numero_nota?: string
            }
            Returns: number
          }
        | {
            Args: {
              p_data_fim?: string
              p_data_inicio?: string
              p_filtro_canal?: string
              p_filtro_marca?: string
              p_filtro_marketplace_pedido?: string
              p_filtro_numero_nota?: string
              p_filtro_status?: string
            }
            Returns: number
          }
      get_produtos_por_nota:
        | {
            Args: {
              p_data_fim?: string
              p_data_inicio?: string
              p_filtro_canal?: string
              p_filtro_id_produto?: string
              p_filtro_marca?: string
              p_filtro_marketplace_pedido?: string
              p_filtro_numero_nota?: string
              p_filtro_status?: string
              p_limit?: number
              p_offset?: number
            }
            Returns: {
              custo_produto_total: number
              frete_proporcional: number
              id_produto: string
              numero_nota: string
              produto_descricao: string
              produto_marca: string
              quantidade: number
              repasse_total: number
              venda_liquida: number
            }[]
          }
        | {
            Args: {
              p_data_fim?: string
              p_data_inicio?: string
              p_filtro_canal?: string
              p_filtro_marca?: string
              p_filtro_marketplace_pedido?: string
              p_filtro_numero_nota?: string
              p_filtro_status?: string
              p_limit?: number
              p_offset?: number
            }
            Returns: {
              custo_produto_total: number
              frete_proporcional: number
              id_produto: string
              numero_nota: string
              produto_descricao: string
              produto_marca: string
              quantidade: number
              repasse_total: number
              venda_liquida: number
            }[]
          }
      get_produtos_por_nota_count:
        | {
            Args: {
              p_data_fim?: string
              p_data_inicio?: string
              p_filtro_canal?: string
              p_filtro_marca?: string
              p_filtro_marketplace_pedido?: string
              p_filtro_numero_nota?: string
              p_filtro_status?: string
            }
            Returns: number
          }
        | {
            Args: {
              p_data_fim?: string
              p_data_inicio?: string
              p_filtro_canal?: string
              p_filtro_id_produto?: string
              p_filtro_marca?: string
              p_filtro_marketplace_pedido?: string
              p_filtro_numero_nota?: string
              p_filtro_status?: string
            }
            Returns: number
          }
      get_repasse_mktp_total: {
        Args: {
          p_data_fim?: string
          p_data_inicio?: string
          p_filtro_canal?: string
        }
        Returns: number
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      haversine_km: {
        Args: { lat1: number; lat2: number; lon1: number; lon2: number }
        Returns: number
      }
      lucrum_create_company: { Args: { p_nome: string }; Returns: string }
      lucrum_has_role: {
        Args: {
          _company_id: string
          _roles: Database["public"]["Enums"]["lucrum_role"][]
          _user_id: string
        }
        Returns: boolean
      }
      lucrum_user_companies: { Args: { _user_id: string }; Returns: string[] }
      normalize_numeric_br: { Args: { p_text: string }; Returns: number }
      refresh_controle_envios_nf: { Args: never; Returns: undefined }
      refresh_mv_analytics: { Args: never; Returns: undefined }
      safe_numeric: { Args: { txt: string }; Returns: number }
    }
    Enums: {
      app_role: "admin" | "analista" | "tv"
      lucrum_role: "owner" | "admin" | "member"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "analista", "tv"],
      lucrum_role: ["owner", "admin", "member"],
    },
  },
} as const
