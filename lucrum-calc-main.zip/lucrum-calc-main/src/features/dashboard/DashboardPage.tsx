import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/features/company/CompanyContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { fmtBRL, fmtPct } from "@/features/simulations/calc";
import { TrendingUp, TrendingDown, AlertTriangle, BarChart3 } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, CartesianGrid } from "recharts";

type Log = {
  id: string; created_at: string; canal_nome: string | null;
  produto_nome: string | null; produto_sku: string | null;
  preco: number; custo: number; lucro: number; margem_pct: number;
};

export function DashboardPage() {
  const { current } = useCompany();
  const companyId = current?.id;

  const logs = useQuery({
    queryKey: ["dash-logs", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("lucrum_simulation_logs")
        .select("id, created_at, canal_nome, produto_nome, produto_sku, preco, custo, lucro, margem_pct")
        .eq("company_id", companyId!)
        .order("created_at", { ascending: false })
        .limit(500);
      if (error) throw error;
      return (data ?? []) as Log[];
    },
  });

  if (!companyId) return <div className="p-8 text-muted-foreground">Selecione uma empresa.</div>;

  const rows = logs.data ?? [];
  const total = rows.length;
  const avgMargin = total ? rows.reduce((a, r) => a + Number(r.margem_pct), 0) / total : 0;
  const negativos = rows.filter(r => Number(r.lucro) < 0);
  const top = [...rows].sort((a, b) => Number(b.lucro) - Number(a.lucro)).slice(0, 5);
  const risco = [...rows].sort((a, b) => Number(a.margem_pct) - Number(b.margem_pct)).slice(0, 5);

  const byChannel = aggregate(rows, r => r.canal_nome ?? "—");

  return (
    <div className="p-6 lg:p-8 max-w-[1500px] mx-auto space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight flex items-center gap-2"><BarChart3 className="h-6 w-6" /> Dashboard</h1>
        <p className="text-sm text-muted-foreground">Visão executiva das simulações recentes.</p>
      </header>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <KPI label="Simulações" value={total.toString()} />
        <KPI label="Margem média" value={fmtPct(avgMargin)} tone={avgMargin >= 0.1 ? "good" : avgMargin >= 0 ? "warn" : "bad"} />
        <KPI label="Margem negativa" value={negativos.length.toString()} tone={negativos.length ? "bad" : "good"} icon={<AlertTriangle className="h-4 w-4" />} />
        <KPI label="Lucro total simulado" value={fmtBRL(rows.reduce((a, r) => a + Number(r.lucro), 0))} />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Margem média por canal</CardTitle></CardHeader>
        <CardContent className="h-72">
          {byChannel.length === 0 ? (
            <div className="text-sm text-muted-foreground">Sem dados ainda. Salve simulações no Simulador.</div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={byChannel}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="key" tick={{ fontSize: 12 }} />
                <YAxis tickFormatter={(v) => `${(v * 100).toFixed(0)}%`} tick={{ fontSize: 12 }} />
                <Tooltip formatter={(v: any) => fmtPct(Number(v))} />
                <Bar dataKey="margem" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4 text-emerald-600" /> Top lucrativos</CardTitle></CardHeader>
          <CardContent><LogList rows={top} /></CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingDown className="h-4 w-4 text-rose-600" /> Risco / margem mais baixa</CardTitle></CardHeader>
          <CardContent><LogList rows={risco} highlight /></CardContent>
        </Card>
      </div>
    </div>
  );
}

function aggregate(rows: Log[], keyFn: (r: Log) => string) {
  const map = new Map<string, { sum: number; n: number }>();
  for (const r of rows) {
    const k = keyFn(r);
    const cur = map.get(k) ?? { sum: 0, n: 0 };
    cur.sum += Number(r.margem_pct); cur.n += 1;
    map.set(k, cur);
  }
  return [...map.entries()].map(([key, v]) => ({ key, margem: v.sum / v.n })).sort((a, b) => b.margem - a.margem);
}

function KPI({ label, value, tone, icon }: { label: string; value: string; tone?: "good" | "warn" | "bad"; icon?: React.ReactNode }) {
  const c = tone === "good" ? "text-emerald-600" : tone === "warn" ? "text-amber-600" : tone === "bad" ? "text-rose-600" : "";
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="text-xs uppercase tracking-wider text-muted-foreground flex items-center gap-1">{icon}{label}</div>
        <div className={`text-2xl font-semibold mt-1 tabular-nums ${c}`}>{value}</div>
      </CardContent>
    </Card>
  );
}

function LogList({ rows, highlight }: { rows: Log[]; highlight?: boolean }) {
  if (rows.length === 0) return <div className="text-sm text-muted-foreground">Sem dados.</div>;
  return (
    <div className="divide-y">
      {rows.map(r => (
        <div key={r.id} className="flex items-center justify-between py-2 text-sm">
          <div className="min-w-0">
            <div className="font-medium truncate">{r.produto_nome ?? r.produto_sku}</div>
            <div className="text-xs text-muted-foreground">{r.canal_nome} · {fmtBRL(Number(r.preco))}</div>
          </div>
          <div className="text-right">
            <div className="tabular-nums font-semibold">{fmtBRL(Number(r.lucro))}</div>
            <Badge variant={highlight && Number(r.margem_pct) < 0 ? "destructive" : "secondary"} className="text-[10px]">{fmtPct(Number(r.margem_pct))}</Badge>
          </div>
        </div>
      ))}
    </div>
  );
}
