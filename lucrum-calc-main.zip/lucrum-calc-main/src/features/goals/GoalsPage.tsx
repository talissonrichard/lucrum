import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/features/company/CompanyContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export function GoalsPage() {
  const { current } = useCompany();
  const [margem, setMargem] = useState<number>(15);
  const [faturamento, setFaturamento] = useState<number>(0);
  const [goalId, setGoalId] = useState<string | null>(null);

  useEffect(() => {
    if (!current) return;
    supabase.from("lucrum_goals").select("*").eq("company_id", current.id).is("channel_id", null).limit(1).maybeSingle()
      .then(({ data }) => {
        if (data) {
          setGoalId(data.id);
          setMargem(Number(data.meta_margem_pct ?? 0.15) * 100);
          setFaturamento(Number(data.meta_faturamento ?? 0));
        }
      });
  }, [current?.id]);

  const save = async () => {
    if (!current) return;
    const payload = { company_id: current.id, channel_id: null, meta_margem_pct: margem/100, meta_faturamento: faturamento };
    const q = goalId ? supabase.from("lucrum_goals").update(payload).eq("id", goalId)
                     : supabase.from("lucrum_goals").insert(payload);
    const { error } = await q;
    if (error) toast.error(error.message); else toast.success("Meta salva");
  };

  return (
    <div className="p-6 lg:p-8 max-w-[700px] mx-auto space-y-6">
      <div><h1 className="text-2xl font-semibold tracking-tight">Metas</h1>
        <p className="text-sm text-muted-foreground">Defina sua meta de margem e faturamento.</p></div>
      <Card>
        <CardHeader><CardTitle>Meta global da empresa</CardTitle><CardDescription>Aplicada a todos os canais (default).</CardDescription></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div><Label>Margem alvo (%)</Label><Input type="number" step="0.1" value={margem || ""} onChange={e => setMargem(Number(e.target.value)||0)} /></div>
            <div><Label>Faturamento alvo (R$)</Label><Input type="number" step="0.01" value={faturamento || ""} onChange={e => setFaturamento(Number(e.target.value)||0)} /></div>
          </div>
          <div className="flex gap-2 text-xs">
            <span className="px-2 py-1 rounded bg-success text-success-foreground">≥ 15% verde</span>
            <span className="px-2 py-1 rounded bg-warning text-warning-foreground">5–15% amarelo</span>
            <span className="px-2 py-1 rounded bg-destructive text-destructive-foreground">{"< 5% vermelho"}</span>
          </div>
          <Button onClick={save}>Salvar meta</Button>
        </CardContent>
      </Card>
    </div>
  );
}
