import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/features/auth/AuthContext";

export type Company = { id: string; nome: string; role: string };

type Ctx = {
  companies: Company[];
  current: Company | null;
  setCurrent: (c: Company) => void;
  loading: boolean;
  reload: () => Promise<void>;
};

const C = createContext<Ctx | null>(null);

export function CompanyProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [current, setCurrentState] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!user) { setCompanies([]); setCurrentState(null); setLoading(false); return; }
    setLoading(true);
    const { data, error } = await supabase
      .from("lucrum_company_users")
      .select("role, lucrum_companies!inner(id, nome)")
      .eq("user_id", user.id);
    if (error) { console.error(error); setLoading(false); return; }
    const list: Company[] = (data ?? []).map((r: any) => ({
      id: r.lucrum_companies.id,
      nome: r.lucrum_companies.nome,
      role: r.role,
    }));
    setCompanies(list);
    const savedId = localStorage.getItem("lucrum.company");
    const found = list.find(c => c.id === savedId) ?? list[0] ?? null;
    setCurrentState(found);
    setLoading(false);
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [user?.id]);

  const setCurrent = (c: Company) => {
    setCurrentState(c);
    localStorage.setItem("lucrum.company", c.id);
  };

  return <C.Provider value={{ companies, current, setCurrent, loading, reload: load }}>{children}</C.Provider>;
}

export function useCompany() {
  const v = useContext(C);
  if (!v) throw new Error("useCompany fora do CompanyProvider");
  return v;
}
