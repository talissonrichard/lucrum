import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "./CompanyContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import { Building2, Plus } from "lucide-react";

export function CreateCompanyDialog({ variant = "default" }: { variant?: "default" | "empty" }) {
  const { reload } = useCompany();
  const [open, setOpen] = useState(false);
  const [nome, setNome] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nome.trim()) return;
    setLoading(true);
    const { error } = await supabase.rpc("lucrum_create_company", { p_nome: nome.trim() });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Empresa criada");
    setNome("");
    setOpen(false);
    await reload();
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {variant === "empty" ? (
          <Button size="sm" variant="secondary" className="w-full mt-2 gap-2">
            <Building2 className="h-4 w-4" /> Criar empresa
          </Button>
        ) : (
          <Button size="sm" variant="ghost" className="w-full mt-1 gap-2 text-xs">
            <Plus className="h-3 w-3" /> Nova empresa
          </Button>
        )}
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Nova empresa</DialogTitle>
          <DialogDescription>Você será cadastrado como owner.</DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="nome">Nome da empresa</Label>
            <Input id="nome" value={nome} onChange={(e) => setNome(e.target.value)} placeholder="Ex: Maxi Ferramentas" autoFocus />
          </div>
          <DialogFooter>
            <Button type="submit" disabled={loading || !nome.trim()}>
              {loading ? "Criando…" : "Criar empresa"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
