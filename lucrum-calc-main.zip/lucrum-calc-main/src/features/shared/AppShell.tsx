import { Link, Outlet, useNavigate, useLocation } from "@tanstack/react-router";
import { useAuth } from "@/features/auth/AuthContext";
import { useCompany } from "@/features/company/CompanyContext";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Calculator, Boxes, Layers, Megaphone, Target, LogOut, Building2, BarChart3, History } from "lucide-react";
import { useEffect } from "react";
import { CreateCompanyDialog } from "@/features/company/CreateCompanyDialog";
import { useRealtimeInvalidation } from "@/features/shared/useRealtimeInvalidation";

const nav = [
  { to: "/app", label: "Dashboard", icon: BarChart3 },
  { to: "/app/simulator", label: "Simulador", icon: Calculator },
  { to: "/app/catalog", label: "Catálogo", icon: Boxes },
  { to: "/app/channels", label: "Canais", icon: Layers },
  { to: "/app/campaigns", label: "Campanhas", icon: Megaphone },
  { to: "/app/goals", label: "Metas", icon: Target },
  { to: "/app/historico", label: "Histórico", icon: History },
];

export function AppShell() {
  const { user, signOut, loading } = useAuth();
  const { companies, current, setCurrent, loading: cLoading } = useCompany();
  const nav2 = useNavigate();
  const loc = useLocation();

  useEffect(() => {
    if (!loading && !user) nav2({ to: "/auth" });
  }, [loading, user, nav2]);

  useRealtimeInvalidation();

  if (loading || !user) return null;

  return (
    <div className="min-h-screen flex bg-background">
      <aside className="w-64 shrink-0 bg-sidebar text-sidebar-foreground flex flex-col">
        <div className="px-6 py-5 border-b border-sidebar-border">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-sidebar-primary text-sidebar-primary-foreground grid place-items-center font-bold">L</div>
            <div>
              <div className="font-semibold tracking-tight">Lucrum</div>
              <div className="text-[10px] uppercase tracking-widest opacity-70">Margem inteligente</div>
            </div>
          </div>
        </div>

        <div className="px-3 py-3 border-b border-sidebar-border">
          <label className="text-[10px] uppercase tracking-widest opacity-70 px-2">Empresa</label>
          {cLoading ? (
            <div className="text-sm px-2 py-2 opacity-70">Carregando…</div>
          ) : companies.length === 0 ? (
            <div className="px-2 py-2">
              <div className="text-xs opacity-70 flex items-start gap-2 mb-1">
                <Building2 className="h-4 w-4 mt-0.5" />
                <span>Sem empresa vinculada.</span>
              </div>
              <CreateCompanyDialog variant="empty" />
            </div>
          ) : (
            <div className="px-1">
              <Select value={current?.id} onValueChange={(id) => {
                const c = companies.find(x => x.id === id); if (c) setCurrent(c);
              }}>
                <SelectTrigger className="bg-sidebar-accent border-sidebar-border text-sidebar-accent-foreground mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {companies.map(c => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}
                </SelectContent>
              </Select>
              <CreateCompanyDialog />
            </div>
          )}
        </div>

        <nav className="flex-1 py-3">
          {nav.map(item => {
            const active = loc.pathname === item.to || (item.to !== "/app" && loc.pathname.startsWith(item.to));
            return (
              <Link key={item.to} to={item.to}
                className={`flex items-center gap-3 px-5 py-2.5 text-sm transition-colors ${
                  active ? "bg-sidebar-accent text-sidebar-accent-foreground border-l-2 border-sidebar-primary" : "hover:bg-sidebar-accent/60"
                }`}>
                <item.icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="p-3 border-t border-sidebar-border">
          <div className="text-xs opacity-70 px-2 mb-2 truncate">{user.email}</div>
          <Button size="sm" variant="ghost" className="w-full justify-start text-sidebar-foreground hover:bg-sidebar-accent"
            onClick={async () => { await signOut(); nav2({ to: "/auth" }); }}>
            <LogOut className="h-4 w-4 mr-2" /> Sair
          </Button>
        </div>
      </aside>

      <main className="flex-1 overflow-auto">
        <Outlet />
      </main>
    </div>
  );
}
