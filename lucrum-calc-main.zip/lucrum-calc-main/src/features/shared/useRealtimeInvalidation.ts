import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

/**
 * Assina mudanças nas tabelas que afetam cálculos de preço/margem e
 * invalida as queries do React Query para que telas abertas (Catálogo,
 * Simulador, Canais, Campanhas, Histórico) re-renderizem com os novos
 * valores automaticamente, sem reload.
 */
export function useRealtimeInvalidation() {
  const qc = useQueryClient();

  useEffect(() => {
    const tables = [
      "lucrum_channels",
      "lucrum_campaigns",
      "lucrum_product_costs",
      "formacao_precos_produtos",
    ];

    const channel = supabase.channel("lucrum-realtime");
    for (const table of tables) {
      channel.on(
        "postgres_changes" as any,
        { event: "*", schema: "public", table },
        () => {
          // Invalida tudo que dependa desses dados — React Query refaz
          // apenas as queries ativas (telas montadas).
          qc.invalidateQueries();
        },
      );
    }
    channel.subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);
}
