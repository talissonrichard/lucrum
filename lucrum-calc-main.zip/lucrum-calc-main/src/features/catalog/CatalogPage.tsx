import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import * as XLSX from "xlsx";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Search, Calculator, ChevronLeft, ChevronRight, Boxes, Download } from "lucide-react";
import { useCatalog, useFacets } from "./useProducts";
import { fmtBRL, fmtPct, simulate, suggestPrice, type ChannelRules } from "@/features/simulations/calc";
import { useCompany } from "@/features/company/CompanyContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const DEFAULT_UPLIFT = 0.20; // Preço Default = sugerido + 20%

function parseMetaPct(s: string | null | undefined): number {
  if (!s) return 0;
  const n = Number(String(s).replace("%", "").replace(",", ".").trim());
  if (!isFinite(n) || n <= 0) return 0;
  return n > 1 ? n / 100 : n;
}

export function CatalogPage() {
  const nav = useNavigate();
  const { current } = useCompany();
  const companyId = current?.id;

  const [search, setSearch] = useState("");
  const [marca, setMarca] = useState<string>("");
  const [categoria, setCategoria] = useState<string>("");
  const [tipo, setTipo] = useState<string>("");
  const [estoque, setEstoque] = useState(false);
  const [page, setPage] = useState(0);
  const pageSize = 50;

  const facets = useFacets();
  const q = useCatalog({ search, marca, categoria, tipo, somenteEstoque: estoque, page, pageSize });
  const total = q.data?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / pageSize));

  // Canal padrão (tabela base de referência) para calcular Preço Default
  const defaultChannel = useQuery({
    queryKey: ["channel-default", companyId],
    enabled: !!companyId,
    staleTime: 60_000,
    queryFn: async () => {
      const { data } = await supabase
        .from("lucrum_channels")
        .select("*")
        .eq("company_id", companyId!)
        .eq("is_default", true)
        .maybeSingle();
      return data as any;
    },
  });

  const baseRules: ChannelRules | null = useMemo(() => {
    const c = defaultChannel.data;
    if (!c) return null;
    return {
      comissao_pct: Number(c.comissao_pct ?? 0),
      imposto_pct: Number(c.imposto_pct ?? 0),
      custo_fixo_1: Number(c.custo_fixo_1 ?? 0),
      custo_fixo_2: Number(c.custo_fixo_2 ?? 0),
      custo_var_1_pct: Number(c.custo_var_1_pct ?? 0),
      custo_var_2_pct: Number(c.custo_var_2_pct ?? 0),
      taxa_marketplace_pct: Number(c.taxa_marketplace ?? 0),
      frete_medio: Number(c.frete_medio ?? 0),
    };
  }, [defaultChannel.data]);

  // Preço sugerido = preço que atinge a meta% do produto na tabela base.
  // Se o produto não tem meta, usa margem 0 (preço mínimo). Preço default = sugerido + 20%.
  const calcPriceLine = (custo: number, metaPct: number) => {
    if (!baseRules || custo <= 0) return { precoSugerido: 0, precoDefault: 0, lucro: 0, margemPct: 0, meta: metaPct };
    const precoSugerido = suggestPrice(custo, baseRules, metaPct);
    const precoDefault = precoSugerido * (1 + DEFAULT_UPLIFT);
    const sim = simulate({ custo, preco: precoDefault, rules: baseRules }, metaPct);
    return { precoSugerido, precoDefault, lucro: sim.lucro, margemPct: sim.margemPct, meta: metaPct };
  };

  const goSimulate = (id: number) => nav({ to: "/app/simulator", search: { produto: id } as any });

  const exportXlsx = async () => {
    if (!baseRules) {
      toast.error("Configure um canal como tabela base de referência em Canais.");
      return;
    }
    toast.loading("Gerando planilha...", { id: "xlsx" });
    try {
      // Busca todas as linhas dos filtros atuais (ignora paginação)
      let qb = supabase.from("formacao_precos_produtos" as any)
        .select("id_produto, codigo_auxiliar, produto_descricao, marca_descricao, categoria, tipo_calculo, custo_final_calculado, preco_tabela_sysemp, qtde_disponivel, meta_margem")
        .order("produto_descricao", { ascending: true })
        .limit(10000);
      if (search) {
        const s = search.replace(/[%,]/g, " ");
        qb = qb.or(`produto_descricao.ilike.%${s}%,codigo_auxiliar.ilike.%${s}%`);
      }
      if (marca) qb = qb.eq("marca_descricao", marca);
      if (categoria) qb = qb.eq("categoria", categoria);
      if (tipo) qb = qb.eq("tipo_calculo", tipo);
      if (estoque) qb = qb.gt("qtde_disponivel", 0);
      const { data, error } = await qb;
      if (error) throw error;
      const rows = (data ?? []).map((p: any) => {
        const custo = Number(p.custo_final_calculado ?? 0);
        const meta = parseMetaPct(p.meta_margem);
        const { precoSugerido, precoDefault, lucro, margemPct } = calcPriceLine(custo, meta);
        return {
          "ID Produto": p.id_produto,
          "SKU": p.codigo_auxiliar ?? "",
          "Descrição": p.produto_descricao ?? "",
          "Marca": p.marca_descricao ?? "",
          "Categoria": p.categoria ?? "",
          "Tipo": p.tipo_calculo ?? "",
          "Custo (R$)": custo,
          "Preço de venda sugerido (R$)": Number(precoSugerido.toFixed(2)),
          "Preço Default (R$)": Number(precoDefault.toFixed(2)),
          "Margem (R$)": Number(lucro.toFixed(2)),
          "Margem (%)": Number((margemPct * 100).toFixed(2)),
          "Estoque": Number(p.qtde_disponivel ?? 0),
        };
      });
      const ws = XLSX.utils.json_to_sheet(rows);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Catálogo");
      XLSX.writeFile(wb, `catalogo-lucrum-${new Date().toISOString().slice(0,10)}.xlsx`);
      toast.success("Planilha gerada.", { id: "xlsx" });
    } catch (e: any) {
      toast.error(e.message ?? "Erro ao gerar planilha", { id: "xlsx" });
    }
  };

  return (
    <div className="p-6 lg:p-8 max-w-[1500px] mx-auto space-y-6">
      <header className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight flex items-center gap-2"><Boxes className="h-6 w-6" /> Catálogo</h1>
          <p className="text-sm text-muted-foreground">Produtos vindos do ERP. Preço sugerido considera a meta % do produto na tabela base; Preço Default = sugerido + {fmtPct(DEFAULT_UPLIFT)}.</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary">{total.toLocaleString("pt-BR")} produtos</Badge>
          {!baseRules && <Badge variant="destructive">Sem canal padrão</Badge>}
          <Button variant="outline" onClick={exportXlsx}><Download className="h-4 w-4 mr-2" />Exportar Excel</Button>
        </div>
      </header>

      <Card>
        <CardContent className="pt-6 grid md:grid-cols-12 gap-3">
          <div className="md:col-span-4">
            <Label className="text-xs">Busca (descrição ou SKU)</Label>
            <div className="relative">
              <Search className="h-4 w-4 absolute left-2.5 top-2.5 text-muted-foreground" />
              <Input className="pl-8" value={search} onChange={(e) => { setSearch(e.target.value); setPage(0); }} placeholder="Ex: cadeira, ABC123…" />
            </div>
          </div>
          <Facet label="Marca" value={marca} onChange={(v) => { setMarca(v); setPage(0); }} options={facets.data?.marcas ?? []} />
          <Facet label="Categoria" value={categoria} onChange={(v) => { setCategoria(v); setPage(0); }} options={facets.data?.categorias ?? []} />
          <Facet label="Tipo" value={tipo} onChange={(v) => { setTipo(v); setPage(0); }} options={facets.data?.tipos ?? []} />
          <div className="md:col-span-2 flex items-end gap-2">
            <div className="flex items-center gap-2 pb-2">
              <Switch checked={estoque} onCheckedChange={(v) => { setEstoque(v); setPage(0); }} />
              <Label className="text-xs">Só com estoque</Label>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0 overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>ID Produto</TableHead>
                <TableHead>SKU</TableHead>
                <TableHead>Descrição</TableHead>
                <TableHead>Marca</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead className="text-right">Custo</TableHead>
                <TableHead className="text-right">Preço de venda sugerido</TableHead>
                <TableHead className="text-right">Preço Default</TableHead>
                <TableHead className="text-right">Margem R$</TableHead>
                <TableHead className="text-right">Margem %</TableHead>
                <TableHead className="text-right">Estoque</TableHead>
                <TableHead className="w-28" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {q.isLoading && <TableRow><TableCell colSpan={12} className="text-center py-8 text-muted-foreground">Carregando…</TableCell></TableRow>}
              {!q.isLoading && q.data?.rows.length === 0 && <TableRow><TableCell colSpan={12} className="text-center py-8 text-muted-foreground">Nenhum produto encontrado.</TableCell></TableRow>}
              {q.data?.rows.map((p) => {
                const custo = Number(p.custo_final_calculado ?? 0);
                const meta = parseMetaPct(p.meta_margem);
                const { precoSugerido, precoDefault, lucro, margemPct } = calcPriceLine(custo, meta);
                const ref = meta > 0 ? meta : 0.20;
                const margemColor = margemPct >= ref ? "text-emerald-600" : margemPct >= ref * 0.6 ? "text-amber-600" : "text-rose-600";
                return (
                  <TableRow key={p.id_produto} className="hover:bg-muted/40">
                    <TableCell className="font-mono font-semibold text-xs">{p.id_produto}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{p.codigo_auxiliar ?? "—"}</TableCell>
                    <TableCell className="font-medium max-w-[360px] truncate">{p.produto_descricao}</TableCell>
                    <TableCell className="text-muted-foreground">{p.marca_descricao ?? "—"}</TableCell>
                    <TableCell><Badge variant={p.tipo_calculo === "KIT" ? "default" : "secondary"}>{p.tipo_calculo ?? "—"}</Badge></TableCell>
                    <TableCell className="text-right tabular-nums">{custo > 0 ? fmtBRL(custo) : "—"}</TableCell>
                    <TableCell className="text-right tabular-nums">{precoSugerido > 0 ? fmtBRL(precoSugerido) : "—"}</TableCell>
                    <TableCell className="text-right tabular-nums font-medium">{precoDefault > 0 ? fmtBRL(precoDefault) : "—"}</TableCell>
                    <TableCell className={`text-right tabular-nums ${margemColor}`}>{precoDefault > 0 ? fmtBRL(lucro) : "—"}</TableCell>
                    <TableCell className={`text-right tabular-nums ${margemColor}`}>{precoDefault > 0 ? fmtPct(margemPct) : "—"}</TableCell>
                    <TableCell className="text-right tabular-nums">{p.qtde_disponivel ?? 0}</TableCell>
                    <TableCell>
                      <Button size="sm" variant="outline" onClick={() => goSimulate(p.id_produto)}>
                        <Calculator className="h-3.5 w-3.5 mr-1" /> Simular
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between text-sm text-muted-foreground">
        <span>Página {page + 1} de {totalPages}</span>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" disabled={page === 0} onClick={() => setPage((p) => Math.max(0, p - 1))}><ChevronLeft className="h-4 w-4" /> Anterior</Button>
          <Button size="sm" variant="outline" disabled={page + 1 >= totalPages} onClick={() => setPage((p) => p + 1)}>Próxima <ChevronRight className="h-4 w-4" /></Button>
        </div>
      </div>
    </div>
  );
}

function Facet({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: string[] }) {
  return (
    <div className="md:col-span-2">
      <Label className="text-xs">{label}</Label>
      <Select value={value || "__all"} onValueChange={(v) => onChange(v === "__all" ? "" : v)}>
        <SelectTrigger><SelectValue placeholder="Todos" /></SelectTrigger>
        <SelectContent>
          <SelectItem value="__all">Todos</SelectItem>
          {options.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
  );
}
