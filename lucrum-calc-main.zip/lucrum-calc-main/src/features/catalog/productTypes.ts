export type ErpProduct = {
  id_produto: number;
  codigo_auxiliar: string | null;
  produto_descricao: string | null;
  tipo_produto_descricao: string | null;
  marca_descricao: string | null;
  categoria: string | null;
  preco_tabela_sysemp: number | null;
  custo: number | null;
  custo_formacao: number | null;
  custo_final_calculado: number | null;
  qtde_disponivel: number | null;
  tipo_calculo: string | null;
  aliq_ipi: number | null;
  produto_comissaoamazon: number | null;
  produto_tarifadba: number | null;
  produto_overfrete: number | null;
  meta_margem: string | null;
  meta_faturamento: string | null;
};

export const ERP_SELECT =
  "id_produto, codigo_auxiliar, produto_descricao, tipo_produto_descricao, marca_descricao, categoria, preco_tabela_sysemp, custo, custo_formacao, custo_final_calculado, qtde_disponivel, tipo_calculo, aliq_ipi, produto_comissaoamazon, produto_tarifadba, produto_overfrete, meta_margem, meta_faturamento";
