import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { ERP_SELECT, type ErpProduct } from "./productTypes";

export type CatalogFilters = {
  search?: string;
  marca?: string;
  categoria?: string;
  tipo?: string;
  somenteEstoque?: boolean;
  page?: number;
  pageSize?: number;
};

function useDebounced<T>(v: T, ms = 300) {
  const [d, setD] = useState(v);
  useEffect(() => { const t = setTimeout(() => setD(v), ms); return () => clearTimeout(t); }, [v, ms]);
  return d;
}

export function useCatalog(filters: CatalogFilters) {
  const search = useDebounced(filters.search ?? "", 300);
  const page = filters.page ?? 0;
  const pageSize = filters.pageSize ?? 50;
  return useQuery({
    queryKey: ["catalog", search, filters.marca, filters.categoria, filters.tipo, filters.somenteEstoque, page, pageSize],
    queryFn: async () => {
      let q = supabase
        .from("formacao_precos_produtos" as any)
        .select(ERP_SELECT, { count: "exact" })
        .order("produto_descricao", { ascending: true })
        .range(page * pageSize, page * pageSize + pageSize - 1);
      if (search) {
        const s = search.replace(/[%,]/g, " ").trim();
        const isNumeric = /^\d+$/.test(s);
        if (isNumeric) {
          q = q.or(`id_produto.eq.${s},produto_descricao.ilike.%${s}%,codigo_auxiliar.ilike.%${s}%`);
        } else {
          q = q.or(`produto_descricao.ilike.%${s}%,codigo_auxiliar.ilike.%${s}%`);
        }
      }
      if (filters.marca) q = q.eq("marca_descricao", filters.marca);
      if (filters.categoria) q = q.eq("categoria", filters.categoria);
      if (filters.tipo) q = q.eq("tipo_calculo", filters.tipo);
      if (filters.somenteEstoque) q = q.gt("qtde_disponivel", 0);
      const { data, error, count } = await q;
      if (error) throw error;
      return { rows: (data ?? []) as unknown as ErpProduct[], total: count ?? 0 };
    },
    staleTime: 30_000,
  });
}

export function useProductById(id: number | null) {
  return useQuery({
    queryKey: ["catalog-item", id],
    enabled: id != null,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("formacao_precos_produtos" as any)
        .select(ERP_SELECT)
        .eq("id_produto", id!)
        .maybeSingle();
      if (error) throw error;
      return data as unknown as ErpProduct | null;
    },
  });
}

export function useFacets() {
  return useQuery({
    queryKey: ["catalog-facets"],
    staleTime: 5 * 60_000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("formacao_precos_produtos" as any)
        .select("marca_descricao, categoria, tipo_calculo")
        .limit(2000);
      if (error) throw error;
      const marcas = new Set<string>(), categorias = new Set<string>(), tipos = new Set<string>();
      for (const r of (data ?? []) as any[]) {
        if (r.marca_descricao) marcas.add(r.marca_descricao);
        if (r.categoria) categorias.add(r.categoria);
        if (r.tipo_calculo) tipos.add(r.tipo_calculo);
      }
      return {
        marcas: [...marcas].sort(),
        categorias: [...categorias].sort(),
        tipos: [...tipos].sort(),
      };
    },
  });
}
