import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/features/company/CompanyContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { fmtPct } from "@/features/simulations/calc";
import { Badge } from "@/components/ui/badge";

type Campaign = { id: string; nome: string; channel_id: string; data_inicio: string; data_fim: string; comissao_promo_pct: number; ativo: boolean };

export function CampaignsPage() {
  const { current } = useCompany();
  const qc = useQueryClient();
  const companyId = current?.id;
  const [open, setOpen] = useState(false);
  const today = new Date().toISOString().slice(0,10);
  const [form, setForm] = useState({ nome: "", channel_id: "", data_inicio: today, data_fim: today, comissao_promo_pct: 0, desconto_obrigatorio_pct: 0, observacoes: "", ativo: true });

  const channels = useQuery({
    queryKey: ["channels", companyId], enabled: !!companyId,
    queryFn: async () => (await supabase.from("lucrum_channels").select("id, nome").eq("company_id", companyId!)).data ?? [],
  });
  const list = useQuery({
    queryKey: ["campaigns-all", companyId], enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("lucrum_campaigns").select("*").eq("company_id", companyId!).order("data_inicio", { ascending: false });
      if (error) throw error; return data as Campaign[];
    },
  });

  const save = async () => {
    if (!companyId || !form.nome || !form.channel_id) return toast.error("Preencha nome e canal");
    const { error } = await supabase.from("lucrum_campaigns").insert({
      company_id: companyId, nome: form.nome, channel_id: form.channel_id,
      data_inicio: form.data_inicio, data_fim: form.data_fim,
      comissao_promo_pct: form.comissao_promo_pct / 100,
      desconto_obrigatorio_pct: form.desconto_obrigatorio_pct / 100,
      observacoes: form.observacoes || null,
      ativo: form.ativo,
    } as any);
    if (error) return toast.error(error.message);
    toast.success("Campanha criada"); setOpen(false);
    qc.invalidateQueries({ queryKey: ["campaigns-all"] });
    qc.invalidateQueries({ queryKey: ["campaigns-active"] });
  };
  const del = async (id: string) => {
    if (!confirm("Excluir campanha?")) return;
    await supabase.from("lucrum_campaigns").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["campaigns-all"] });
    qc.invalidateQueries({ queryKey: ["campaigns-active"] });
  };

  const isActive = (c: Campaign) => c.ativo && c.data_inicio <= today && c.data_fim >= today;

  return (
    <div className="p-6 lg:p-8 max-w-[1200px] mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-semibold tracking-tight">Campanhas</h1>
          <p className="text-sm text-muted-foreground">Sobrescreve a comissão padrão do canal no período.</p></div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-2" /> Nova campanha</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Nova campanha</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div><Label>Nome</Label><Input value={form.nome} onChange={e => setForm(f => ({ ...f, nome: e.target.value }))} /></div>
              <div><Label>Canal</Label>
                <Select value={form.channel_id} onValueChange={v => setForm(f => ({ ...f, channel_id: v }))}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>{channels.data?.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Início</Label><Input type="date" value={form.data_inicio} onChange={e => setForm(f => ({ ...f, data_inicio: e.target.value }))} /></div>
                <div><Label>Fim</Label><Input type="date" value={form.data_fim} onChange={e => setForm(f => ({ ...f, data_fim: e.target.value }))} /></div>
              </div>
              <div><Label>Comissão promocional (%)</Label><Input type="number" step="0.01" value={form.comissao_promo_pct || ""} onChange={e => setForm(f => ({ ...f, comissao_promo_pct: Number(e.target.value) || 0 }))} /></div>
              <div><Label>Desconto obrigatório (%)</Label><Input type="number" step="0.01" value={form.desconto_obrigatorio_pct || ""} onChange={e => setForm(f => ({ ...f, desconto_obrigatorio_pct: Number(e.target.value) || 0 }))} /></div>
              <div><Label>Observações</Label><Input value={form.observacoes} onChange={e => setForm(f => ({ ...f, observacoes: e.target.value }))} placeholder="Opcional" /></div>
              <div className="flex items-center gap-2"><Switch checked={form.ativo} onCheckedChange={v => setForm(f => ({ ...f, ativo: v }))} /><Label>Ativo</Label></div>
            </div>
            <DialogFooter><Button onClick={save}>Criar</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card><CardContent className="pt-6">
        <Table>
          <TableHeader><TableRow><TableHead>Nome</TableHead><TableHead>Canal</TableHead><TableHead>Período</TableHead><TableHead>Comissão</TableHead><TableHead>Status</TableHead><TableHead className="w-16"></TableHead></TableRow></TableHeader>
          <TableBody>
            {list.data?.map(c => {
              const ch = channels.data?.find((x: any) => x.id === c.channel_id);
              return (
                <TableRow key={c.id}>
                  <TableCell className="font-medium">{c.nome}</TableCell>
                  <TableCell>{ch?.nome ?? "—"}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">{c.data_inicio} → {c.data_fim}</TableCell>
                  <TableCell>{fmtPct(Number(c.comissao_promo_pct))}</TableCell>
                  <TableCell>{isActive(c) ? <Badge className="bg-success text-success-foreground">Ativa</Badge> : <Badge variant="secondary">Inativa</Badge>}</TableCell>
                  <TableCell className="text-right"><Button size="icon" variant="ghost" onClick={() => del(c.id)}><Trash2 className="h-4 w-4" /></Button></TableCell>
                </TableRow>
              );
            })}
            {list.data?.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">Nenhuma campanha.</TableCell></TableRow>}
          </TableBody>
        </Table>
      </CardContent></Card>
    </div>
  );
}
