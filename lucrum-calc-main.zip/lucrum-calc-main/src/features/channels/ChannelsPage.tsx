import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/features/company/CompanyContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Plus, Trash2, Pencil } from "lucide-react";
import { toast } from "sonner";
import { fmtPct, fmtBRL } from "@/features/simulations/calc";

type Channel = {
  id: string; nome: string;
  comissao_pct: number; imposto_pct: number;
  custo_fixo_1: number; custo_fixo_1_label: string;
  custo_fixo_2: number; custo_fixo_2_label: string;
  custo_var_1_pct: number; custo_var_1_label: string;
  custo_var_2_pct: number; custo_var_2_label: string;
  frete_medio: number; taxa_marketplace: number;
  ativo: boolean;
  is_default: boolean;
};

const empty: Channel = {
  id: "", nome: "",
  comissao_pct: 0, imposto_pct: 0,
  custo_fixo_1: 0, custo_fixo_1_label: "Frete embutido",
  custo_fixo_2: 0, custo_fixo_2_label: "Embalagem",
  custo_var_1_pct: 0, custo_var_1_label: "Pgto / antifraude",
  custo_var_2_pct: 0, custo_var_2_label: "Outros",
  frete_medio: 0, taxa_marketplace: 0,
  ativo: true,
  is_default: false,
};

export function ChannelsPage() {
  const { current } = useCompany();
  const qc = useQueryClient();
  const companyId = current?.id;
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<Channel>(empty);

  const channels = useQuery({
    queryKey: ["channels-full", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("lucrum_channels").select("*").eq("company_id", companyId!).order("nome");
      if (error) throw error; return data as Channel[];
    },
  });

  // Inputs aceitam % humano (15) e convertem para 0.15
  const setPct = (k: keyof Channel) => (v: string) => setForm(f => ({ ...f, [k]: (Number(v) || 0) / 100 } as any));
  const setNum = (k: keyof Channel) => (v: string) => setForm(f => ({ ...f, [k]: Number(v) || 0 } as any));
  const setStr = (k: keyof Channel) => (v: string) => setForm(f => ({ ...f, [k]: v } as any));

  const save = async () => {
    if (!companyId) return;
    if (!form.nome) return toast.error("Informe o nome");
    // Se marcando como default, desmarcar os outros antes
    if (form.is_default) {
      await supabase.from("lucrum_channels").update({ is_default: false } as any)
        .eq("company_id", companyId).neq("id", form.id || "00000000-0000-0000-0000-000000000000");
    }
    const payload: any = { ...form, company_id: companyId };
    delete payload.id;
    const q = form.id
      ? supabase.from("lucrum_channels").update(payload).eq("id", form.id)
      : supabase.from("lucrum_channels").insert(payload);
    const { error } = await q;
    if (error) return toast.error(error.message);
    toast.success("Salvo"); setOpen(false); setForm(empty);
    qc.invalidateQueries({ queryKey: ["channels-full"] });
    qc.invalidateQueries({ queryKey: ["channels"] });
    qc.invalidateQueries({ queryKey: ["channel-default"] });
  };

  const del = async (id: string) => {
    if (!confirm("Excluir canal?")) return;
    const { error } = await supabase.from("lucrum_channels").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Excluído"); qc.invalidateQueries({ queryKey: ["channels-full"] }); }
  };

  return (
    <div className="p-6 lg:p-8 max-w-[1200px] mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div><h1 className="text-2xl font-semibold tracking-tight">Canais de venda</h1>
          <p className="text-sm text-muted-foreground">Comissão, imposto e custos aplicados em cada canal.</p></div>
        <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setForm(empty); }}>
          <DialogTrigger asChild><Button><Plus className="h-4 w-4 mr-2" /> Novo canal</Button></DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader><DialogTitle>{form.id ? "Editar canal" : "Novo canal"}</DialogTitle></DialogHeader>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2"><Label>Nome do canal</Label><Input value={form.nome} onChange={e => setStr("nome")(e.target.value)} placeholder="Ex: Shopee, Mercado Livre, Loja própria" /></div>
              <div><Label>Comissão (%)</Label><Input type="number" step="0.01" value={(form.comissao_pct*100) || ""} onChange={e => setPct("comissao_pct")(e.target.value)} /></div>
              <div><Label>Imposto (%)</Label><Input type="number" step="0.01" value={(form.imposto_pct*100) || ""} onChange={e => setPct("imposto_pct")(e.target.value)} /></div>

              <div><Label>{form.custo_var_1_label} — %</Label><Input type="number" step="0.01" value={(form.custo_var_1_pct*100) || ""} onChange={e => setPct("custo_var_1_pct")(e.target.value)} /></div>
              <div><Label>Rótulo var. 1</Label><Input value={form.custo_var_1_label} onChange={e => setStr("custo_var_1_label")(e.target.value)} /></div>
              <div><Label>{form.custo_var_2_label} — %</Label><Input type="number" step="0.01" value={(form.custo_var_2_pct*100) || ""} onChange={e => setPct("custo_var_2_pct")(e.target.value)} /></div>
              <div><Label>Rótulo var. 2</Label><Input value={form.custo_var_2_label} onChange={e => setStr("custo_var_2_label")(e.target.value)} /></div>

              <div><Label>{form.custo_fixo_1_label} — R$</Label><Input type="number" step="0.01" value={form.custo_fixo_1 || ""} onChange={e => setNum("custo_fixo_1")(e.target.value)} /></div>
              <div><Label>Rótulo fixo 1</Label><Input value={form.custo_fixo_1_label} onChange={e => setStr("custo_fixo_1_label")(e.target.value)} /></div>
              <div><Label>{form.custo_fixo_2_label} — R$</Label><Input type="number" step="0.01" value={form.custo_fixo_2 || ""} onChange={e => setNum("custo_fixo_2")(e.target.value)} /></div>
              <div><Label>Rótulo fixo 2</Label><Input value={form.custo_fixo_2_label} onChange={e => setStr("custo_fixo_2_label")(e.target.value)} /></div>
              <div><Label>Frete médio (R$)</Label><Input type="number" step="0.01" value={form.frete_medio || ""} onChange={e => setNum("frete_medio")(e.target.value)} /></div>
              <div><Label>Taxa marketplace (%)</Label><Input type="number" step="0.01" value={(form.taxa_marketplace*100) || ""} onChange={e => setPct("taxa_marketplace")(e.target.value)} /></div>
              <div className="col-span-2 flex items-center gap-3 rounded-lg border border-dashed p-3">
                <input id="is_default" type="checkbox" className="h-4 w-4" checked={form.is_default} onChange={e => setForm(f => ({ ...f, is_default: e.target.checked }))} />
                <Label htmlFor="is_default" className="cursor-pointer text-sm">
                  <span className="font-medium">Tabela base de referência</span>
                  <span className="block text-xs text-muted-foreground">Usado pelo Catálogo para calcular o "Preço Default" (apenas 1 canal por empresa).</span>
                </Label>
              </div>
            </div>
            <DialogFooter><Button onClick={save}>Salvar</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardContent className="pt-6">
          <Table>
            <TableHeader><TableRow>
              <TableHead>Canal</TableHead><TableHead>Comissão</TableHead><TableHead>Imposto</TableHead>
              <TableHead>Custos var.</TableHead><TableHead>Custos fixos</TableHead><TableHead className="w-24"></TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {channels.data?.map(c => (
                <TableRow key={c.id}>
                  <TableCell className="font-medium">{c.nome} {c.is_default && <Badge variant="secondary" className="ml-2">Tabela base</Badge>}</TableCell>
                  <TableCell>{fmtPct(Number(c.comissao_pct))}</TableCell>
                  <TableCell>{fmtPct(Number(c.imposto_pct))}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{fmtPct(Number(c.custo_var_1_pct))} + {fmtPct(Number(c.custo_var_2_pct))}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">{fmtBRL(Number(c.custo_fixo_1))} + {fmtBRL(Number(c.custo_fixo_2))}</TableCell>
                  <TableCell className="text-right">
                    <Button size="icon" variant="ghost" onClick={() => { setForm(c); setOpen(true); }}><Pencil className="h-4 w-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => del(c.id)}><Trash2 className="h-4 w-4" /></Button>
                  </TableCell>
                </TableRow>
              ))}
              {channels.data?.length === 0 && <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-8">Nenhum canal cadastrado.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
