import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/features/company/CompanyContext";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { fmtBRL, fmtPct } from "@/features/simulations/calc";
import { History } from "lucide-react";

export function SimulationLogsPage() {
  const { current } = useCompany();
  const companyId = current?.id;

  const q = useQuery({
    queryKey: ["sim-logs", companyId],
    enabled: !!companyId,
    queryFn: async () => {
      const { data, error } = await supabase.from("lucrum_simulation_logs")
        .select("id, created_at, canal_nome, produto_nome, produto_sku, preco, custo, lucro, margem_pct")
        .eq("company_id", companyId!).order("created_at", { ascending: false }).limit(200);
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <div className="p-6 lg:p-8 max-w-[1400px] mx-auto space-y-6">
      <header>
        <h1 className="text-2xl font-semibold tracking-tight flex items-center gap-2"><History className="h-6 w-6" /> Histórico de simulações</h1>
        <p className="text-sm text-muted-foreground">Últimas 200 simulações salvas.</p>
      </header>
      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Produto</TableHead>
                <TableHead>Canal</TableHead>
                <TableHead className="text-right">Custo</TableHead>
                <TableHead className="text-right">Preço</TableHead>
                <TableHead className="text-right">Lucro</TableHead>
                <TableHead className="text-right">Margem</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {q.data?.map((r: any) => (
                <TableRow key={r.id}>
                  <TableCell className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleString("pt-BR")}</TableCell>
                  <TableCell className="font-medium max-w-[360px] truncate">{r.produto_nome ?? r.produto_sku}</TableCell>
                  <TableCell>{r.canal_nome}</TableCell>
                  <TableCell className="text-right tabular-nums">{fmtBRL(Number(r.custo))}</TableCell>
                  <TableCell className="text-right tabular-nums">{fmtBRL(Number(r.preco))}</TableCell>
                  <TableCell className={`text-right tabular-nums ${Number(r.lucro) < 0 ? "text-rose-600" : ""}`}>{fmtBRL(Number(r.lucro))}</TableCell>
                  <TableCell className="text-right">
                    <Badge variant={Number(r.margem_pct) < 0 ? "destructive" : "secondary"}>{fmtPct(Number(r.margem_pct))}</Badge>
                  </TableCell>
                </TableRow>
              ))}
              {q.data?.length === 0 && <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">Nenhuma simulação salva ainda.</TableCell></TableRow>}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
