// Núcleo de cálculo de margem (puro, frontend-first)
export type ChannelRules = {
  comissao_pct: number;
  imposto_pct: number;
  custo_fixo_1: number;
  custo_fixo_2: number;
  custo_var_1_pct: number;
  custo_var_2_pct: number;
  taxa_marketplace_pct?: number;
  frete_medio?: number;
};

export type SimInput = {
  custo: number;
  preco: number;
  rules: ChannelRules;
};

export type SimResult = {
  receita: number;
  custoProduto: number;
  comissao: number;
  imposto: number;
  custoVar1: number;
  custoVar2: number;
  taxaMkt: number;
  custoFixo1: number;
  custoFixo2: number;
  freteMedio: number;
  totalDeducoes: number;
  lucro: number;
  margemPct: number;
  cmvPct: number;
  markup: number;
  precoMinimo: number;
  status: "verde" | "amarelo" | "vermelho";
};

const pctsVar = (r: ChannelRules) =>
  r.comissao_pct + r.imposto_pct + r.custo_var_1_pct + r.custo_var_2_pct + (r.taxa_marketplace_pct ?? 0);

const fixosTotais = (r: ChannelRules) =>
  r.custo_fixo_1 + r.custo_fixo_2 + (r.frete_medio ?? 0);

export function precoMinimo(custo: number, r: ChannelRules): number {
  const denom = 1 - pctsVar(r);
  if (denom <= 0) return 0;
  return (custo + fixosTotais(r)) / denom;
}

export function simulate({ custo, preco, rules }: SimInput, metaMargem = 0.15): SimResult {
  const receita = preco;
  const comissao = preco * rules.comissao_pct;
  const imposto = preco * rules.imposto_pct;
  const custoVar1 = preco * rules.custo_var_1_pct;
  const custoVar2 = preco * rules.custo_var_2_pct;
  const taxaMkt = preco * (rules.taxa_marketplace_pct ?? 0);
  const custoFixo1 = rules.custo_fixo_1;
  const custoFixo2 = rules.custo_fixo_2;
  const freteMedio = rules.frete_medio ?? 0;
  const totalDeducoes = comissao + imposto + custoVar1 + custoVar2 + taxaMkt + custoFixo1 + custoFixo2 + freteMedio;
  const lucro = receita - custo - totalDeducoes;
  const margemPct = preco > 0 ? lucro / preco : 0;
  const cmvPct = preco > 0 ? custo / preco : 0;
  const markup = custo > 0 ? preco / custo : 0;

  let status: SimResult["status"] = "vermelho";
  if (margemPct >= metaMargem) status = "verde";
  else if (margemPct >= metaMargem * 0.6) status = "amarelo";

  return {
    receita, custoProduto: custo, comissao, imposto,
    custoVar1, custoVar2, taxaMkt, custoFixo1, custoFixo2, freteMedio,
    totalDeducoes, lucro, margemPct, cmvPct, markup,
    precoMinimo: precoMinimo(custo, rules),
    status,
  };
}

export function suggestPrice(custo: number, rules: ChannelRules, margemAlvo: number): number {
  const denom = 1 - (pctsVar(rules) + margemAlvo);
  if (denom <= 0) return 0;
  return (custo + fixosTotais(rules)) / denom;
}

export function suggestPriceForMarkup(custo: number, markupAlvo: number): number {
  return custo * markupAlvo;
}

export const fmtBRL = (n: number) =>
  (isFinite(n) ? n : 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL", minimumFractionDigits: 2 });

export const fmtPct = (n: number) =>
  ((isFinite(n) ? n : 0) * 100).toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "%";
