import { useEffect, useMemo, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useSearch } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useCompany } from "@/features/company/CompanyContext";
import { simulate, suggestPrice, fmtBRL, fmtPct, type ChannelRules } from "./calc";
import { useCatalog, useProductById } from "@/features/catalog/useProducts";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, Sparkles, TrendingUp, TrendingDown, Minus, Search } from "lucide-react";
import { toast } from "sonner";

type Channel = {
  id: string; nome: string;
  comissao_pct: number; imposto_pct: number;
  custo_fixo_1: number; custo_fixo_1_label: string | null;
  custo_fixo_2: number; custo_fixo_2_label: string | null;
  custo_var_1_pct: number; custo_var_1_label: string | null;
  custo_var_2_pct: number; custo_var_2_label: string | null;
  frete_medio: number; taxa_marketplace: number;
};
type Campaign = { id: string; nome: string; channel_id: string; data_inicio: string; data_fim: string; comissao_promo_pct: number; ativo: boolean; desconto_obrigatorio_pct: number };
type Goal = { meta_margem_pct: number | null };

export function Simulator() {
  const { current } = useCompany();
  const companyId = current?.id;
  const search = useSearch({ strict: false }) as { produto?: number };

  const [productSearch, setProductSearch] = useState("");
  const [productId, setProductId] = useState<number | null>(search.produto ?? null);
  const [channelId, setChannelId] = useState<string>("");
  const [custoOverride, setCustoOverride] = useState<number | null>(null);
  const [preco, setPreco] = useState<number>(0);

  const list = useCatalog({ search: productSearch, pageSize: 20 });
  const productQ = useProductById(productId);
  const product = productQ.data;
  const custo = custoOverride != null ? custoOverride : Number(product?.custo_final_calculado ?? 0);

  const channels = useQuery({
    queryKey: ["channels", companyId],
    enabled: !!companyId,
    staleTime: 60_000,
    queryFn: async () => {
      const { data, error } = await supabase.from("lucrum_channels").select("*").eq("company_id", companyId!).eq("ativo", true).order("nome");
      if (error) throw error;
      return data as unknown as Channel[];
    },
  });

  const campaigns = useQuery({
    queryKey: ["campaigns-active", companyId],
    enabled: !!companyId,
    staleTime: 60_000,
    queryFn: async () => {
      const today = new Date().toISOString().slice(0, 10);
      const { data, error } = await supabase.from("lucrum_campaigns").select("*")
        .eq("company_id", companyId!).eq("ativo", true).lte("data_inicio", today).gte("data_fim", today);
      if (error) throw error;
      return data as unknown as Campaign[];
    },
  });

  const channel = channels.data?.find((c) => c.id === channelId);
  const activeCampaign = campaigns.data?.find((c) => c.channel_id === channelId);

  // Meta sempre vem do produto (ERP). Sem meta no produto = 0.
  const parsePct = (v: string | null | undefined): number => {
    if (!v) return 0;
    const n = Number(String(v).replace("%", "").replace(",", ".").trim());
    return Number.isFinite(n) ? n / 100 : 0;
  };
  const parseBRL = (v: string | null | undefined): number => {
    if (!v) return 0;
    const n = Number(String(v).replace(/\./g, "").replace(",", ".").trim());
    return Number.isFinite(n) ? n : 0;
  };
  const metaMargem = parsePct(product?.meta_margem);
  const metaFatMes = parseBRL(product?.meta_faturamento);
  const diasNoMes = (() => {
    const d = new Date();
    return new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
  })();
  const metaFatDia = metaFatMes / diasNoMes;

  const rules: ChannelRules = useMemo(() => ({
    comissao_pct: activeCampaign ? Number(activeCampaign.comissao_promo_pct) : Number(channel?.comissao_pct ?? 0),
    imposto_pct: Number(channel?.imposto_pct ?? 0),
    custo_fixo_1: Number(channel?.custo_fixo_1 ?? 0),
    custo_fixo_2: Number(channel?.custo_fixo_2 ?? 0),
    custo_var_1_pct: Number(channel?.custo_var_1_pct ?? 0),
    custo_var_2_pct: Number(channel?.custo_var_2_pct ?? 0),
    taxa_marketplace_pct: Number(channel?.taxa_marketplace ?? 0),
    frete_medio: Number(channel?.frete_medio ?? 0),
  }), [channel, activeCampaign]);

  const result = useMemo(() => simulate({ custo, preco, rules }, metaMargem), [custo, preco, rules, metaMargem]);
  const sugestao = useMemo(() => suggestPrice(custo, rules, metaMargem), [custo, rules, metaMargem]);

  // Sincroniza com ?produto= da URL (vinda do Catálogo)
  const lastUrlProduto = useRef<number | undefined>(undefined);
  useEffect(() => {
    if (search.produto && search.produto !== lastUrlProduto.current) {
      lastUrlProduto.current = search.produto;
      setProductId(search.produto);
      setProductSearch("");
      setCustoOverride(null);
      setPreco(0);
    }
  }, [search.produto]);

  // Inicia preço com sugestão quando produto/canal mudam
  useEffect(() => {
    if (preco === 0 && product && channel) {
      const base = Number(product.preco_tabela_sysemp ?? 0) || sugestao;
      if (base > 0) setPreco(Number(base.toFixed(2)));
    }
    // eslint-disable-next-line
  }, [product?.id_produto, channelId]);

  const saveLog = async () => {
    if (!companyId || !productId || !channelId) { toast.error("Selecione produto e canal."); return; }
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase.from("lucrum_simulation_logs").insert({
      company_id: companyId, user_id: user!.id,
      product_id: null, channel_id: channelId,
      erp_id_produto: productId,
      campaign_id: activeCampaign?.id ?? null,
      produto_nome: product?.produto_descricao ?? null,
      produto_sku: product?.codigo_auxiliar ?? String(productId),
      canal_nome: channel?.nome,
      custo, preco,
      comissao_pct: rules.comissao_pct, imposto_pct: rules.imposto_pct,
      custo_fixo_1: rules.custo_fixo_1, custo_fixo_2: rules.custo_fixo_2,
      custo_var_1_pct: rules.custo_var_1_pct, custo_var_2_pct: rules.custo_var_2_pct,
      taxa_marketplace_pct: rules.taxa_marketplace_pct ?? 0,
      frete_medio: rules.frete_medio ?? 0,
      lucro: result.lucro, margem_pct: result.margemPct, markup: result.markup,
    } as any);
    if (error) toast.error(error.message); else toast.success("Simulação salva.");
  };

  if (!companyId) return <div className="p-8 text-muted-foreground">Selecione uma empresa.</div>;

  const statusColor = result.status === "verde" ? "bg-emerald-600 text-white"
    : result.status === "amarelo" ? "bg-amber-500 text-white"
    : "bg-rose-600 text-white";
  const TrendIcon = result.lucro > 0 ? TrendingUp : result.lucro < 0 ? TrendingDown : Minus;

  return (
    <div className="p-6 lg:p-8 max-w-[1500px] mx-auto space-y-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Simulador de Margem</h1>
          <p className="text-sm text-muted-foreground">Cálculo em tempo real para decisão comercial.</p>
        </div>
        <Button onClick={saveLog} disabled={!productId || !channelId}>
          <Save className="h-4 w-4 mr-2" /> Salvar simulação
        </Button>
      </header>

      <div className="grid lg:grid-cols-5 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Entradas</CardTitle><CardDescription>Produto, canal e preço.</CardDescription></CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Produto</Label>
              <div className="relative">
                <Search className="h-4 w-4 absolute left-2.5 top-2.5 text-muted-foreground" />
                <Input className="pl-8" placeholder="Buscar por ID do produto, SKU ou descrição…" value={productSearch} onChange={(e) => setProductSearch(e.target.value)} />
              </div>
              {(productSearch || !product) && (
                <div className="mt-2 max-h-56 overflow-auto rounded-md border bg-card divide-y text-sm">
                  {list.data?.rows.slice(0, 10).map((p) => (
                    <button key={p.id_produto} onClick={() => { setProductId(p.id_produto); setProductSearch(""); setCustoOverride(null); setPreco(0); }}
                      className="w-full text-left px-3 py-2 hover:bg-muted/60">
                      <div className="font-medium truncate">{p.produto_descricao}</div>
                      <div className="text-xs text-muted-foreground flex justify-between">
                        <span><span className="font-mono">#{p.id_produto}</span> · {p.codigo_auxiliar ?? "—"} · {p.marca_descricao ?? "—"} · {p.tipo_calculo}</span>
                        <span>{fmtBRL(Number(p.custo_final_calculado ?? 0))}</span>
                      </div>
                    </button>
                  ))}
                  {list.data?.rows.length === 0 && <div className="px-3 py-3 text-muted-foreground">Sem resultados.</div>}
                </div>
              )}
              {product && (
                <div className="mt-2 rounded-md border bg-muted/30 p-3 text-sm">
                  <div className="font-medium">{product.produto_descricao}</div>
                  <div className="text-xs text-muted-foreground flex flex-wrap gap-x-3">
                    <span className="font-mono font-semibold">ID #{product.id_produto}</span>
                    <span>SKU {product.codigo_auxiliar ?? "—"}</span>
                    <span>{product.marca_descricao}</span>
                    <span>{product.categoria}</span>
                    <Badge variant={product.tipo_calculo === "KIT" ? "default" : "secondary"} className="text-[10px]">{product.tipo_calculo}</Badge>
                    <span>Estoque {product.qtde_disponivel ?? 0}</span>
                  </div>
                </div>
              )}
            </div>

            <div>
              <Label>Canal de venda</Label>
              <Select value={channelId} onValueChange={setChannelId}>
                <SelectTrigger><SelectValue placeholder="Selecione um canal" /></SelectTrigger>
                <SelectContent>
                  {channels.data?.map((c) => <SelectItem key={c.id} value={c.id}>{c.nome}</SelectItem>)}
                </SelectContent>
              </Select>
              {activeCampaign && (
                <div className="mt-2 text-xs flex items-center gap-2">
                  <Badge className="bg-accent text-accent-foreground">Campanha ativa</Badge>
                  <span className="text-muted-foreground">{activeCampaign.nome} · comissão {fmtPct(Number(activeCampaign.comissao_promo_pct))}</span>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Custo (R$)</Label>
                <Input type="number" step="0.01" value={custo || ""} onChange={(e) => setCustoOverride(Number(e.target.value) || 0)} />
              </div>
              <div>
                <Label>Preço (R$)</Label>
                <Input type="number" step="0.01" value={preco || ""} onChange={(e) => setPreco(Number(e.target.value) || 0)} />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs"><span className="text-muted-foreground">Ajuste fino</span><span className="font-medium">{fmtBRL(preco)}</span></div>
              <Slider value={[preco]} min={0} max={Math.max(custo * 5, preco * 1.5, 1000)} step={0.5} onValueChange={(v) => setPreco(v[0])} />
            </div>

            {channel && (
              <div className="rounded-lg bg-muted/50 p-3 text-xs space-y-1">
                <div className="font-medium text-foreground mb-1">Regras — {channel.nome}</div>
                <Row label="Comissão" v={fmtPct(rules.comissao_pct)} alert={!!activeCampaign} />
                <Row label="Imposto" v={fmtPct(rules.imposto_pct)} />
                <Row label="Taxa marketplace" v={fmtPct(rules.taxa_marketplace_pct ?? 0)} />
                <Row label={channel.custo_var_1_label || "Custo var. 1"} v={fmtPct(rules.custo_var_1_pct)} />
                <Row label={channel.custo_var_2_label || "Custo var. 2"} v={fmtPct(rules.custo_var_2_pct)} />
                <Row label={channel.custo_fixo_1_label || "Custo fixo 1"} v={fmtBRL(rules.custo_fixo_1)} />
                <Row label={channel.custo_fixo_2_label || "Custo fixo 2"} v={fmtBRL(rules.custo_fixo_2)} />
                <Row label="Frete médio" v={fmtBRL(rules.frete_medio ?? 0)} />
              </div>
            )}

            {custo > 0 && (
              <div className="grid grid-cols-2 gap-2">
                <SuggestCard label={`Preço meta ${fmtPct(metaMargem)}`} value={sugestao} onApply={() => setPreco(Number(sugestao.toFixed(2)))} />
                <SuggestCard label="Preço mínimo (margem 0)" value={result.precoMinimo} onApply={() => setPreco(Number(result.precoMinimo.toFixed(2)))} />
              </div>
            )}
          </CardContent>
        </Card>

        <div className="lg:col-span-3 space-y-6">
          <Card className="overflow-hidden">
            <div className={`px-6 py-5 ${statusColor}`}>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs uppercase tracking-widest opacity-90">Lucro líquido</div>
                  <div className="text-3xl font-bold tracking-tight flex items-center gap-2">
                    <TrendIcon className="h-7 w-7" />{fmtBRL(result.lucro)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs uppercase tracking-widest opacity-90">Margem</div>
                  <div className="text-3xl font-bold">{fmtPct(result.margemPct)}</div>
                  <div className="text-xs opacity-90 mt-1 space-y-0.5">
                    <div>Meta margem: {fmtPct(metaMargem)}</div>
                    <div>Meta R$ mês: {fmtBRL(metaFatMes)} · dia: {fmtBRL(metaFatDia)}</div>
                  </div>
                </div>
              </div>
            </div>
            <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6">
              <Stat label="Receita" value={fmtBRL(result.receita)} />
              <Stat label="Custo total" value={fmtBRL(result.custoProduto + result.totalDeducoes)} />
              <Stat label="Markup" value={result.markup ? `${result.markup.toFixed(2)}x` : "—"} />
              <Stat label="CMV" value={fmtPct(result.cmvPct)} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Composição</CardTitle></CardHeader>
            <CardContent className="space-y-2 text-sm">
              <Line label="Receita" value={result.receita} />
              <Line label="(–) Custo do produto" value={-result.custoProduto} />
              <Line label="(–) Comissão" value={-result.comissao} />
              <Line label="(–) Imposto" value={-result.imposto} />
              <Line label="(–) Taxa marketplace" value={-result.taxaMkt} />
              <Line label="(–) Custo variável 1" value={-result.custoVar1} />
              <Line label="(–) Custo variável 2" value={-result.custoVar2} />
              <Line label="(–) Custo fixo 1" value={-result.custoFixo1} />
              <Line label="(–) Custo fixo 2" value={-result.custoFixo2} />
              <Line label="(–) Frete médio" value={-result.freteMedio} />
              <div className="border-t pt-2 mt-2 flex justify-between font-semibold">
                <span>Lucro</span><span className={result.lucro >= 0 ? "text-emerald-600" : "text-rose-600"}>{fmtBRL(result.lucro)}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Row({ label, v, alert }: { label: string; v: string; alert?: boolean }) {
  return <div className="flex justify-between"><span className="text-muted-foreground">{label}</span><span className={alert ? "font-semibold text-primary" : ""}>{v}</span></div>;
}
function Stat({ label, value }: { label: string; value: string }) {
  return <div><div className="text-xs text-muted-foreground uppercase tracking-wider">{label}</div><div className="text-lg font-semibold tabular-nums">{value}</div></div>;
}
function Line({ label, value }: { label: string; value: number }) {
  return <div className="flex justify-between"><span className="text-muted-foreground">{label}</span><span className="tabular-nums">{fmtBRL(value)}</span></div>;
}
function SuggestCard({ label, value, onApply }: { label: string; value: number; onApply: () => void }) {
  return (
    <div className="rounded-lg border border-dashed p-3 flex items-center justify-between gap-2">
      <div className="text-xs min-w-0">
        <div className="flex items-center gap-1 font-medium"><Sparkles className="h-3.5 w-3.5" /> {label}</div>
        <div className="text-muted-foreground tabular-nums truncate">{fmtBRL(value)}</div>
      </div>
      <Button size="sm" variant="outline" onClick={onApply} disabled={!value || !isFinite(value)}>Usar</Button>
    </div>
  );
}
