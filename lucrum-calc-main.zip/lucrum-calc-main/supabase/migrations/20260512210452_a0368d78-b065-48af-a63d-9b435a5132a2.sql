
-- Enable RLS + read policy for ERP product table
ALTER TABLE public.formacao_precos_produtos ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Authenticated can read formacao_precos_produtos" ON public.formacao_precos_produtos;
CREATE POLICY "Authenticated can read formacao_precos_produtos"
ON public.formacao_precos_produtos FOR SELECT TO authenticated USING (true);

-- Indexes for fast catalog search
CREATE INDEX IF NOT EXISTS idx_fpp_descricao ON public.formacao_precos_produtos (produto_descricao);
CREATE INDEX IF NOT EXISTS idx_fpp_marca ON public.formacao_precos_produtos (marca_descricao);
CREATE INDEX IF NOT EXISTS idx_fpp_categoria ON public.formacao_precos_produtos (categoria);
CREATE INDEX IF NOT EXISTS idx_fpp_codigo_aux ON public.formacao_precos_produtos (codigo_auxiliar);
CREATE INDEX IF NOT EXISTS idx_fpp_id_produto ON public.formacao_precos_produtos (id_produto);

-- New columns on lucrum_channels
ALTER TABLE public.lucrum_channels
  ADD COLUMN IF NOT EXISTS frete_medio numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS taxa_marketplace numeric NOT NULL DEFAULT 0;

-- New columns on lucrum_campaigns
ALTER TABLE public.lucrum_campaigns
  ADD COLUMN IF NOT EXISTS desconto_obrigatorio_pct numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS observacoes text;

-- New columns on lucrum_goals (metas por marca/categoria)
ALTER TABLE public.lucrum_goals
  ADD COLUMN IF NOT EXISTS marca text,
  ADD COLUMN IF NOT EXISTS categoria text;

-- ERP product link in simulation logs
ALTER TABLE public.lucrum_simulation_logs
  ADD COLUMN IF NOT EXISTS erp_id_produto bigint,
  ADD COLUMN IF NOT EXISTS frete_medio numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS taxa_marketplace_pct numeric NOT NULL DEFAULT 0,
  ALTER COLUMN product_id DROP NOT NULL;
