
-- Enum de papéis dentro da empresa
CREATE TYPE public.lucrum_role AS ENUM ('owner', 'admin', 'member');

-- Empresas
CREATE TABLE public.lucrum_companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  nome TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Vínculo usuário ↔ empresa
CREATE TABLE public.lucrum_company_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.lucrum_companies(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  role public.lucrum_role NOT NULL DEFAULT 'member',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (company_id, user_id)
);
CREATE INDEX idx_lucrum_company_users_user ON public.lucrum_company_users(user_id);

-- Produtos
CREATE TABLE public.lucrum_products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.lucrum_companies(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  sku TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (company_id, sku)
);
CREATE INDEX idx_lucrum_products_company ON public.lucrum_products(company_id);

-- Custos importados (histórico, não armazenado em produtos)
CREATE TABLE public.lucrum_product_costs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.lucrum_companies(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.lucrum_products(id) ON DELETE CASCADE,
  custo NUMERIC(14,4) NOT NULL,
  origem TEXT NOT NULL DEFAULT 'manual', -- manual | excel | api | erp
  referencia TEXT,
  data_custo DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_lucrum_product_costs_product ON public.lucrum_product_costs(product_id, data_custo DESC);
CREATE INDEX idx_lucrum_product_costs_company ON public.lucrum_product_costs(company_id);

-- Canais
CREATE TABLE public.lucrum_channels (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.lucrum_companies(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  comissao_pct NUMERIC(7,4) NOT NULL DEFAULT 0,
  imposto_pct NUMERIC(7,4) NOT NULL DEFAULT 0,
  custo_fixo_1 NUMERIC(14,4) NOT NULL DEFAULT 0,
  custo_fixo_1_label TEXT DEFAULT 'Custo fixo 1',
  custo_fixo_2 NUMERIC(14,4) NOT NULL DEFAULT 0,
  custo_fixo_2_label TEXT DEFAULT 'Custo fixo 2',
  custo_var_1_pct NUMERIC(7,4) NOT NULL DEFAULT 0,
  custo_var_1_label TEXT DEFAULT 'Custo variável 1',
  custo_var_2_pct NUMERIC(7,4) NOT NULL DEFAULT 0,
  custo_var_2_label TEXT DEFAULT 'Custo variável 2',
  ativo BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_lucrum_channels_company ON public.lucrum_channels(company_id);

-- Campanhas
CREATE TABLE public.lucrum_campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.lucrum_companies(id) ON DELETE CASCADE,
  channel_id UUID NOT NULL REFERENCES public.lucrum_channels(id) ON DELETE CASCADE,
  nome TEXT NOT NULL,
  data_inicio DATE NOT NULL,
  data_fim DATE NOT NULL,
  comissao_promo_pct NUMERIC(7,4) NOT NULL,
  prioridade INTEGER NOT NULL DEFAULT 0,
  ativo BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_lucrum_campaigns_channel ON public.lucrum_campaigns(channel_id, data_inicio, data_fim);
CREATE INDEX idx_lucrum_campaigns_company ON public.lucrum_campaigns(company_id);

-- Simulações salvas (snapshot)
CREATE TABLE public.lucrum_simulation_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.lucrum_companies(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  product_id UUID REFERENCES public.lucrum_products(id) ON DELETE SET NULL,
  channel_id UUID REFERENCES public.lucrum_channels(id) ON DELETE SET NULL,
  campaign_id UUID REFERENCES public.lucrum_campaigns(id) ON DELETE SET NULL,
  -- snapshot
  produto_nome TEXT,
  produto_sku TEXT,
  canal_nome TEXT,
  custo NUMERIC(14,4) NOT NULL,
  preco NUMERIC(14,4) NOT NULL,
  comissao_pct NUMERIC(7,4) NOT NULL,
  imposto_pct NUMERIC(7,4) NOT NULL,
  custo_fixo_1 NUMERIC(14,4) NOT NULL DEFAULT 0,
  custo_fixo_2 NUMERIC(14,4) NOT NULL DEFAULT 0,
  custo_var_1_pct NUMERIC(7,4) NOT NULL DEFAULT 0,
  custo_var_2_pct NUMERIC(7,4) NOT NULL DEFAULT 0,
  -- resultados
  lucro NUMERIC(14,4) NOT NULL,
  margem_pct NUMERIC(9,6) NOT NULL,
  markup NUMERIC(9,6) NOT NULL,
  observacao TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_lucrum_sim_logs_company ON public.lucrum_simulation_logs(company_id, created_at DESC);

-- Itens da simulação (preparado para múltiplos itens por simulação)
CREATE TABLE public.lucrum_simulation_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  simulation_id UUID NOT NULL REFERENCES public.lucrum_simulation_logs(id) ON DELETE CASCADE,
  produto_sku TEXT,
  produto_nome TEXT,
  quantidade NUMERIC(14,4) NOT NULL DEFAULT 1,
  custo NUMERIC(14,4) NOT NULL,
  preco NUMERIC(14,4) NOT NULL,
  lucro NUMERIC(14,4) NOT NULL,
  margem_pct NUMERIC(9,6) NOT NULL
);
CREATE INDEX idx_lucrum_sim_items_sim ON public.lucrum_simulation_items(simulation_id);

-- Metas
CREATE TABLE public.lucrum_goals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.lucrum_companies(id) ON DELETE CASCADE,
  channel_id UUID REFERENCES public.lucrum_channels(id) ON DELETE CASCADE,
  meta_margem_pct NUMERIC(7,4),
  meta_faturamento NUMERIC(14,2),
  periodo_inicio DATE,
  periodo_fim DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_lucrum_goals_company ON public.lucrum_goals(company_id);

-- Função security definer: empresas do usuário
CREATE OR REPLACE FUNCTION public.lucrum_user_companies(_user_id UUID)
RETURNS SETOF UUID
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT company_id FROM public.lucrum_company_users WHERE user_id = _user_id
$$;

-- Função: usuário tem papel na empresa
CREATE OR REPLACE FUNCTION public.lucrum_has_role(_user_id UUID, _company_id UUID, _roles public.lucrum_role[])
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.lucrum_company_users
    WHERE user_id = _user_id
      AND company_id = _company_id
      AND role = ANY(_roles)
  )
$$;

-- Trigger updated_at genérico
CREATE OR REPLACE FUNCTION public.lucrum_set_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_lucrum_companies_uat BEFORE UPDATE ON public.lucrum_companies FOR EACH ROW EXECUTE FUNCTION public.lucrum_set_updated_at();
CREATE TRIGGER trg_lucrum_products_uat  BEFORE UPDATE ON public.lucrum_products  FOR EACH ROW EXECUTE FUNCTION public.lucrum_set_updated_at();
CREATE TRIGGER trg_lucrum_channels_uat  BEFORE UPDATE ON public.lucrum_channels  FOR EACH ROW EXECUTE FUNCTION public.lucrum_set_updated_at();
CREATE TRIGGER trg_lucrum_campaigns_uat BEFORE UPDATE ON public.lucrum_campaigns FOR EACH ROW EXECUTE FUNCTION public.lucrum_set_updated_at();
CREATE TRIGGER trg_lucrum_goals_uat     BEFORE UPDATE ON public.lucrum_goals     FOR EACH ROW EXECUTE FUNCTION public.lucrum_set_updated_at();

-- RLS
ALTER TABLE public.lucrum_companies        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lucrum_company_users    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lucrum_products         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lucrum_product_costs    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lucrum_channels         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lucrum_campaigns        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lucrum_simulation_logs  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lucrum_simulation_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lucrum_goals            ENABLE ROW LEVEL SECURITY;

-- Companies: usuário vê apenas as suas
CREATE POLICY "view own companies" ON public.lucrum_companies FOR SELECT TO authenticated
  USING (id IN (SELECT public.lucrum_user_companies(auth.uid())));

-- Company users: usuário vê os vínculos da própria empresa
CREATE POLICY "view company members" ON public.lucrum_company_users FOR SELECT TO authenticated
  USING (company_id IN (SELECT public.lucrum_user_companies(auth.uid())));
CREATE POLICY "owners manage members" ON public.lucrum_company_users FOR ALL TO authenticated
  USING (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]))
  WITH CHECK (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]));

-- Macro: políticas padrão por tabela (read all members; write admin/owner)
-- Products
CREATE POLICY "read products"  ON public.lucrum_products FOR SELECT TO authenticated
  USING (company_id IN (SELECT public.lucrum_user_companies(auth.uid())));
CREATE POLICY "write products" ON public.lucrum_products FOR ALL TO authenticated
  USING (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]))
  WITH CHECK (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]));

-- Product costs
CREATE POLICY "read product_costs"  ON public.lucrum_product_costs FOR SELECT TO authenticated
  USING (company_id IN (SELECT public.lucrum_user_companies(auth.uid())));
CREATE POLICY "write product_costs" ON public.lucrum_product_costs FOR ALL TO authenticated
  USING (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]))
  WITH CHECK (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]));

-- Channels
CREATE POLICY "read channels"  ON public.lucrum_channels FOR SELECT TO authenticated
  USING (company_id IN (SELECT public.lucrum_user_companies(auth.uid())));
CREATE POLICY "write channels" ON public.lucrum_channels FOR ALL TO authenticated
  USING (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]))
  WITH CHECK (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]));

-- Campaigns
CREATE POLICY "read campaigns"  ON public.lucrum_campaigns FOR SELECT TO authenticated
  USING (company_id IN (SELECT public.lucrum_user_companies(auth.uid())));
CREATE POLICY "write campaigns" ON public.lucrum_campaigns FOR ALL TO authenticated
  USING (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]))
  WITH CHECK (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]));

-- Goals
CREATE POLICY "read goals"  ON public.lucrum_goals FOR SELECT TO authenticated
  USING (company_id IN (SELECT public.lucrum_user_companies(auth.uid())));
CREATE POLICY "write goals" ON public.lucrum_goals FOR ALL TO authenticated
  USING (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]))
  WITH CHECK (public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]));

-- Simulation logs: qualquer membro lê e cria
CREATE POLICY "read sim logs"   ON public.lucrum_simulation_logs FOR SELECT TO authenticated
  USING (company_id IN (SELECT public.lucrum_user_companies(auth.uid())));
CREATE POLICY "create sim logs" ON public.lucrum_simulation_logs FOR INSERT TO authenticated
  WITH CHECK (
    company_id IN (SELECT public.lucrum_user_companies(auth.uid()))
    AND user_id = auth.uid()
  );
CREATE POLICY "update own sim logs" ON public.lucrum_simulation_logs FOR UPDATE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "delete own sim logs" ON public.lucrum_simulation_logs FOR DELETE TO authenticated
  USING (user_id = auth.uid() OR public.lucrum_has_role(auth.uid(), company_id, ARRAY['owner','admin']::public.lucrum_role[]));

-- Simulation items: herdam do log
CREATE POLICY "read sim items"  ON public.lucrum_simulation_items FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.lucrum_simulation_logs l WHERE l.id = simulation_id AND l.company_id IN (SELECT public.lucrum_user_companies(auth.uid()))));
CREATE POLICY "write sim items" ON public.lucrum_simulation_items FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.lucrum_simulation_logs l WHERE l.id = simulation_id AND l.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.lucrum_simulation_logs l WHERE l.id = simulation_id AND l.user_id = auth.uid()));
