ALTER TABLE public.lucrum_channels ADD COLUMN IF NOT EXISTS is_default boolean NOT NULL DEFAULT false;
CREATE UNIQUE INDEX IF NOT EXISTS lucrum_channels_one_default_per_company
  ON public.lucrum_channels(company_id) WHERE is_default = true;