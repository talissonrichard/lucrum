
-- 1) Enable RLS and add authenticated-only read policies on exposed tables
DO $$
DECLARE
  t text;
  tbls text[] := ARRAY[
    'bi_agenda_obrigacoes','bi_faturas','bi_marcas','bi_motivos_crm',
    'bi_nota_saida','bi_nota_saida_itens','bi_produtos','bi_transporte_regras',
    'cmv_pedidos_dia','controle_envios_nf_raw_bruto','fato_repasse_mktp',
    'produto_estado_atual','produto_snapshot','produto_snapshot_current_job',
    'produto_event_log','job_execution_log','regras_governanca',
    'tv_dashboards','tv_expedicao_pendente'
  ];
BEGIN
  FOREACH t IN ARRAY tbls LOOP
    EXECUTE format('ALTER TABLE public.%I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('DROP POLICY IF EXISTS "Authenticated can read %1$s" ON public.%1$I', t);
    EXECUTE format(
      'CREATE POLICY "Authenticated can read %1$s" ON public.%1$I FOR SELECT TO authenticated USING (true)',
      t
    );
  END LOOP;
END $$;

-- 2) notas_saida: replace permissive policy
ALTER TABLE public.notas_saida ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Permitir tudo para autenticados" ON public.notas_saida;
CREATE POLICY "Authenticated can read notas_saida"
  ON public.notas_saida FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage notas_saida"
  ON public.notas_saida FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 3) metricas_personalizadas: tighten
ALTER TABLE public.metricas_personalizadas ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all access to metricas_personalizadas" ON public.metricas_personalizadas;
CREATE POLICY "Authenticated can read metricas_personalizadas"
  ON public.metricas_personalizadas FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage metricas_personalizadas"
  ON public.metricas_personalizadas FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 4) itens_sem_repasse: tighten
ALTER TABLE public.itens_sem_repasse ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all access to itens_sem_repasse" ON public.itens_sem_repasse;
CREATE POLICY "Authenticated can read itens_sem_repasse"
  ON public.itens_sem_repasse FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins can manage itens_sem_repasse"
  ON public.itens_sem_repasse FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 5) tv_relatorios: tighten
ALTER TABLE public.tv_relatorios ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Allow all for authenticated on tv_relatorios" ON public.tv_relatorios;
DROP POLICY IF EXISTS "Allow public read on tv_relatorios" ON public.tv_relatorios;
CREATE POLICY "Authenticated can read tv_relatorios"
  ON public.tv_relatorios FOR SELECT TO authenticated USING (true);
CREATE POLICY "Admins manage tv_relatorios"
  ON public.tv_relatorios FOR ALL TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 6) tvs: tighten (table exists per scan)
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_tables WHERE schemaname='public' AND tablename='tvs') THEN
    EXECUTE 'ALTER TABLE public.tvs ENABLE ROW LEVEL SECURITY';
    EXECUTE 'DROP POLICY IF EXISTS "Allow all for authenticated on tvs" ON public.tvs';
    EXECUTE 'DROP POLICY IF EXISTS "Allow public read on tvs" ON public.tvs';
    EXECUTE 'CREATE POLICY "Authenticated can read tvs" ON public.tvs FOR SELECT TO authenticated USING (true)';
    EXECUTE 'CREATE POLICY "Admins manage tvs" ON public.tvs FOR ALL TO authenticated USING (has_role(auth.uid(), ''admin''::app_role)) WITH CHECK (has_role(auth.uid(), ''admin''::app_role))';
  END IF;
END $$;

-- 7) configuracoes: remove anon tv_mode write policy
DROP POLICY IF EXISTS "Allow anon to manage tv_mode config" ON public.configuracoes;

-- 8) Storage: lock down dashboard image writes to authenticated
DROP POLICY IF EXISTS "Service role can manage dashboard images" ON storage.objects;
DROP POLICY IF EXISTS "Service role can update dashboard images" ON storage.objects;
DROP POLICY IF EXISTS "Service role can delete dashboard images" ON storage.objects;

CREATE POLICY "Authenticated can upload dashboard images"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'dashboards');
CREATE POLICY "Authenticated can update dashboard images"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'dashboards')
  WITH CHECK (bucket_id = 'dashboards');
CREATE POLICY "Authenticated can delete dashboard images"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'dashboards');

-- 9) Set fixed search_path on Lucrum functions
ALTER FUNCTION public.lucrum_user_companies(uuid) SET search_path = public;
ALTER FUNCTION public.lucrum_has_role(uuid, uuid, lucrum_role[]) SET search_path = public;
ALTER FUNCTION public.lucrum_set_updated_at() SET search_path = public;
