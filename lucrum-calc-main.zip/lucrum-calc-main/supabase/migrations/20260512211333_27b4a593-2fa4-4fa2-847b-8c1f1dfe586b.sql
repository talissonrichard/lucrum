CREATE OR REPLACE FUNCTION public.lucrum_create_company(p_nome text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_company_id uuid;
  v_uid uuid := auth.uid();
BEGIN
  IF v_uid IS NULL THEN
    RAISE EXCEPTION 'not authenticated';
  END IF;
  IF p_nome IS NULL OR length(trim(p_nome)) = 0 THEN
    RAISE EXCEPTION 'nome obrigatório';
  END IF;

  INSERT INTO public.lucrum_companies (nome) VALUES (trim(p_nome))
    RETURNING id INTO v_company_id;

  INSERT INTO public.lucrum_company_users (company_id, user_id, role)
    VALUES (v_company_id, v_uid, 'owner');

  RETURN v_company_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.lucrum_create_company(text) TO authenticated;