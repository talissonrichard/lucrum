# Plano de Evolução — Lucrum

São 11 mudanças que afetam DB, RLS, UI e fluxo de auth. Vou agrupar em **4 entregas sequenciais** para manter qualidade e permitir validação intermediária. Cada entrega é independente e pode ser aprovada antes de seguir.

---

## Entrega 1 — Catálogo + Simulador (itens 1, 2, 3, 4, 5, 6)

**Catálogo (`CatalogPage`)**
- Coluna primária = `id_produto` (mostrado em destaque, monospace). SKU/codigo_auxiliar vira coluna secundária.
- Colunas obrigatórias: `id_produto`, descrição, **Custo** (`custo_final_calculado`), **Preço de venda sugerido** (renomear de "Preço tabela" → usa `preco_tabela_sysemp`), **Preço Default** (calculado), **Margem R$**, **Margem %**.
- **Preço Default** = `suggestPrice(custo, regrasTabelaPadrão, 0.20)` — usa um canal marcado como "Tabela base de referência" (flag `is_default` em `lucrum_channels`) e meta de margem fixa 20%.
- **Margem R$ / %** = calculadas sobre o Preço Default vs custo, deduzindo custos da tabela padrão.
- Botão **"Exportar Excel"** no header → gera `.xlsx` com todas as linhas filtradas (xlsx via SheetJS no client).
- Botão **Simular** → `navigate({ to: "/app/simulator", search: { produto: id_produto } })` (já está parcialmente, garantir auto-seleção no Simulator).

**Simulador (`Simulator`)**
- Barra de busca aceita `id_produto` (numérico) além de SKU/descrição. Quando vem via `?produto=<id>`, pré-seleciona automaticamente.

**Banco**
- `ALTER TABLE lucrum_channels ADD COLUMN is_default boolean DEFAULT false;`
- Índice único parcial garantindo no máx. 1 canal default por empresa.

---

## Entrega 2 — Perfis Admin/Analista + Gestão de Usuários (itens 7, 10)

**Roles**
- Já existe enum `lucrum_role` com `owner | admin | member`. Vou usar `member` como **analista** e adicionar lógica:
  - **Admin/Owner**: CRUD canais, campanhas, fretes, configurações, cadastra usuários.
  - **Analista (member)**: somente leitura em canais/configs; pode simular e exportar histórico.
- RLS já restringe writes — só ajustar UI para esconder botões quando `member`.

**Cadastro de usuários (admin)**
- Nova página `/app/usuarios` (somente admin).
- Server function `lucrum_admin_create_user` (usa `supabaseAdmin.auth.admin.createUser`) → cria usuário com email + senha temporária, vincula ao company atual como `member`, marca flag `must_change_password`.
- Tabela `lucrum_user_profiles` (user_id, must_change_password bool, nome, created_by).

**Auth**
- Remover botão "Criar conta" da tela `/auth` (login somente).
- No primeiro login (must_change_password=true) → redireciona para `/app/trocar-senha` antes de liberar o app.

---

## Entrega 3 — Histórico de Auditoria + Dashboard Diagnóstico (itens 8, 9)

**Auditoria**
- Nova tabela `lucrum_audit_log`:
  - `entity` (channel|simulation|campaign|freight), `entity_id`, `action` (insert|update|delete), `user_id`, `user_email`, `company_id`, `valor_antigo jsonb`, `valor_novo jsonb`, `created_at`.
- Trigger `AFTER INSERT/UPDATE/DELETE` em `lucrum_channels`, `lucrum_campaigns`, `lucrum_freight_tables` (criada na entrega 4) gravando old/new.
- Simulações já gravam em `lucrum_simulation_logs` — adicionar `user_email` desnormalizado para exibição.
- Página `/app/historico` ganha **2 abas**: "Simulações" (existente) + "Alterações" (audit_log) com filtros.

**Dashboard**
- Cards de diagnóstico:
  - Última atualização de custo (`MAX(data_importacao)` em `formacao_precos_produtos`).
  - Total de produtos / com estoque / sem custo.
  - Canais ativos / Campanhas vigentes.
  - Simulações últimos 7 dias.
  - Margem média das simulações recentes.
  - Alertas: produtos sem meta_margem, canais sem frete configurado.

---

## Entrega 4 — Tabelas de Frete (item 11)

**Modelo de dados**
```text
lucrum_freight_tables          (cabeçalho)
  id, company_id, channel_id (opcional), nome, tipo (proprio|parceiro),
  modo_calculo (faixa_peso|faixa_preco|categoria|regiao|dimensao|tabela_custom),
  ativo, created_at, updated_at

lucrum_freight_rules           (regras detalhadas)
  id, freight_table_id,
  faixa_min numeric, faixa_max numeric,   -- peso/preço/qtd
  categoria text, marca text, uf text,
  dim_min numeric, dim_max numeric,
  valor_coparticipacao numeric,           -- valor fixo OU
  pct_coparticipacao numeric              -- percentual sobre o preço
```

**UI**
- Nova rota `/app/fretes` com listagem + CRUD (admin only).
- Editor de regras dinâmico baseado em `modo_calculo`.

**Integração no simulador**
- Ao escolher um canal "parceiro" com tabela de frete vinculada, o simulador resolve a regra aplicável (peso/preço/categoria do produto) e injeta `coparticipacao_frete` no cálculo (`calc.ts`) — entra como custo variável adicional.
- Cenário 1 (frete próprio) = comportamento atual, sem ajuste.

---

## Migrações de banco necessárias (resumo)

1. `lucrum_channels.is_default` (entrega 1)
2. `lucrum_user_profiles` + função `lucrum_admin_create_user` (entrega 2)
3. `lucrum_audit_log` + triggers (entrega 3)
4. `lucrum_freight_tables`, `lucrum_freight_rules` + RLS (entrega 4)

---

## Como prefere proceder?

Recomendo aprovar **uma entrega de cada vez** (começando pela 1), validar em preview, depois seguir. Posso também executar tudo de uma vez se preferir velocidade — me avise.
